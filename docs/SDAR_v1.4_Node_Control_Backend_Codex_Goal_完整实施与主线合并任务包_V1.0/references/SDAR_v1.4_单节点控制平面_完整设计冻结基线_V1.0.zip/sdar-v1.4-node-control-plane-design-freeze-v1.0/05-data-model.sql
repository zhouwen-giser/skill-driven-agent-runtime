-- SDAR v1.4 Node Control Plane fresh baseline.
-- This is a frozen logical baseline; implementation migration must preserve these authorities.
-- No legacy experimental database compatibility is provided. Frozen: 2026-07-31.

CREATE SCHEMA IF NOT EXISTS sdar_control;

CREATE TABLE sdar_control.node_profile (
    node_id text PRIMARY KEY,
    node_type text NOT NULL,
    display_name text NOT NULL,
    description text NOT NULL DEFAULT '',
    environment text NOT NULL,
    labels jsonb NOT NULL DEFAULT '{}'::jsonb,
    authority_scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
    runtime_endpoint_ref text NOT NULL,
    telemetry_endpoint_ref text,
    status text NOT NULL CHECK (status IN ('draft','active','maintenance','retired')),
    revision bigint NOT NULL DEFAULT 1,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sdar_control.configuration_revision (
    configuration_id text NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    revision bigint NOT NULL,
    status text NOT NULL CHECK (
      status IN ('draft','validated','published','applying','applied',
                 'partially_applied','rejected','rolled_back')
    ),
    apply_mode text NOT NULL CHECK (
      apply_mode IN ('hot_reload','new_task_only','reconnect_required',
                     'restart_required','immutable')
    ),
    content jsonb NOT NULL,
    checksum char(64) NOT NULL,
    created_by text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    published_at timestamptz,
    PRIMARY KEY (configuration_id, revision),
    UNIQUE (target_type, target_id, revision)
);

CREATE TABLE sdar_control.configuration_application (
    application_id text PRIMARY KEY,
    configuration_id text NOT NULL,
    revision bigint NOT NULL,
    runtime_instance_id text NOT NULL,
    status text NOT NULL CHECK (
      status IN ('pending','staging','applied','partially_applied',
                 'rejected','restart_required','stale','unavailable')
    ),
    observed_runtime_version text,
    active_checksum char(64),
    reason_code text,
    detail jsonb NOT NULL DEFAULT '{}'::jsonb,
    acknowledged_at timestamptz,
    UNIQUE (configuration_id, revision, runtime_instance_id),
    FOREIGN KEY (configuration_id, revision)
      REFERENCES sdar_control.configuration_revision(configuration_id, revision)
);

CREATE TABLE sdar_control.llm_provider_definition (
    provider_id text PRIMARY KEY,
    provider_type text NOT NULL,
    base_url text NOT NULL,
    credential_ref text NOT NULL,
    model_catalog jsonb NOT NULL DEFAULT '[]'::jsonb,
    health_policy jsonb NOT NULL DEFAULT '{}'::jsonb,
    rate_limit_policy jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL CHECK (
      status IN ('draft','active','degraded','suspended','retired')
    ),
    revision bigint NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sdar_control.smpp_registry_source (
    smpp_source_id text PRIMARY KEY,
    name text NOT NULL,
    registry_endpoint text NOT NULL,
    credential_ref text NOT NULL,
    environment text NOT NULL,
    tenant_id text,
    project_id text,
    sync_mode text NOT NULL CHECK (sync_mode IN ('manual','poll','watch')),
    snapshot_ttl_seconds integer NOT NULL CHECK (snapshot_ttl_seconds > 0),
    lkg_policy text NOT NULL CHECK (
      lkg_policy IN ('allow_unexpired','deny_when_unavailable')
    ),
    status text NOT NULL CHECK (status IN ('draft','active','suspended','retired')),
    revision bigint NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sdar_control.smpp_registry_snapshot (
    smpp_source_id text NOT NULL,
    revision bigint NOT NULL,
    checksum char(64) NOT NULL,
    content jsonb NOT NULL,
    status text NOT NULL CHECK (status IN ('staged','active','superseded','rejected')),
    fetched_at timestamptz NOT NULL,
    valid_until timestamptz NOT NULL,
    PRIMARY KEY (smpp_source_id, revision),
    FOREIGN KEY (smpp_source_id)
      REFERENCES sdar_control.smpp_registry_source(smpp_source_id)
);

CREATE TABLE sdar_control.mcp_provider_binding (
    binding_id text PRIMARY KEY,
    local_server_id text NOT NULL UNIQUE,
    origin_type text NOT NULL CHECK (origin_type IN ('direct','smpp_registry')),
    smpp_source_id text,
    external_provider_id text,
    external_server_id text,
    registry_revision bigint,
    registry_checksum char(64),
    catalog_revision text NOT NULL,
    catalog_checksum char(64) NOT NULL,
    endpoint_ref text NOT NULL,
    status text NOT NULL CHECK (
      status IN ('candidate','imported','active','degraded','suspended','removed')
    ),
    revision bigint NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (
      (origin_type = 'direct' AND smpp_source_id IS NULL)
      OR
      (origin_type = 'smpp_registry'
       AND smpp_source_id IS NOT NULL
       AND external_provider_id IS NOT NULL
       AND external_server_id IS NOT NULL)
    )
);

CREATE TABLE sdar_control.node_capability (
    capability_id text PRIMARY KEY,
    domain text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sdar_control.node_capability_version (
    capability_id text NOT NULL,
    version bigint NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    input_schema jsonb NOT NULL,
    output_schema jsonb NOT NULL,
    success_criteria jsonb NOT NULL,
    required_evidence jsonb NOT NULL,
    effects jsonb NOT NULL DEFAULT '[]'::jsonb,
    artifacts jsonb NOT NULL DEFAULT '[]'::jsonb,
    constraints jsonb NOT NULL DEFAULT '[]'::jsonb,
    supported_modes jsonb NOT NULL DEFAULT '[]'::jsonb,
    risk_level text NOT NULL CHECK (risk_level IN ('low','medium','high','critical')),
    status text NOT NULL CHECK (
      status IN ('draft','validating','published','suspended',
                 'deprecated','retired')
    ),
    definition_hash char(64) NOT NULL,
    previous_version bigint,
    created_by text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (capability_id, version),
    UNIQUE (capability_id, definition_hash),
    FOREIGN KEY (capability_id)
      REFERENCES sdar_control.node_capability(capability_id)
);

CREATE TABLE sdar_control.capability_implementation_binding (
    binding_id text PRIMARY KEY,
    capability_id text NOT NULL,
    capability_version bigint NOT NULL,
    implementation_type text NOT NULL CHECK (
      implementation_type IN ('skill','plan_template')
    ),
    implementation_id text NOT NULL,
    implementation_version text NOT NULL,
    role text NOT NULL CHECK (
      role IN ('primary','alternative','supporting','validation','recovery')
    ),
    priority integer NOT NULL DEFAULT 100,
    activation_condition jsonb,
    provider_policy_override jsonb,
    status text NOT NULL CHECK (status IN ('draft','active','suspended','retired')),
    revision bigint NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (
      capability_id, capability_version,
      implementation_type, implementation_id, implementation_version, role
    ),
    FOREIGN KEY (capability_id, capability_version)
      REFERENCES sdar_control.node_capability_version(capability_id, version)
);

CREATE TABLE sdar_control.a2a_exposure (
    exposure_id text PRIMARY KEY,
    agent_skill_id text NOT NULL UNIQUE,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sdar_control.a2a_exposure_version (
    exposure_id text NOT NULL,
    version bigint NOT NULL,
    capability_id text NOT NULL,
    capability_version bigint NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    tags jsonb NOT NULL DEFAULT '[]'::jsonb,
    examples jsonb NOT NULL DEFAULT '[]'::jsonb,
    input_modes jsonb NOT NULL DEFAULT '[]'::jsonb,
    output_modes jsonb NOT NULL DEFAULT '[]'::jsonb,
    request_schema jsonb NOT NULL,
    result_schema jsonb NOT NULL,
    visibility text NOT NULL CHECK (visibility IN ('organization','public')),
    requester_policy jsonb NOT NULL DEFAULT '{}'::jsonb,
    readiness_publication_policy text NOT NULL CHECK (
      readiness_publication_policy IN (
        'publish_when_available','publish_degraded','always_publish_with_status'
      )
    ),
    status text NOT NULL CHECK (status IN ('draft','published','suspended','retired')),
    exposure_hash char(64) NOT NULL,
    created_by text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (exposure_id, version),
    FOREIGN KEY (exposure_id)
      REFERENCES sdar_control.a2a_exposure(exposure_id),
    FOREIGN KEY (capability_id, capability_version)
      REFERENCES sdar_control.node_capability_version(capability_id, version)
);

CREATE TABLE sdar_control.agent_card_publication (
    publication_id text PRIMARY KEY,
    revision bigint NOT NULL UNIQUE,
    candidate_content jsonb NOT NULL,
    content_hash char(64) NOT NULL UNIQUE,
    capability_catalog_hash char(64) NOT NULL,
    status text NOT NULL CHECK (
      status IN ('candidate','published','applied','rejected','superseded')
    ),
    runtime_ack jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    applied_at timestamptz
);

CREATE TABLE sdar_control.telemetry_link (
    telemetry_link_id text PRIMARY KEY,
    endpoint_ref text NOT NULL,
    credential_ref text,
    environment text NOT NULL,
    query_capabilities jsonb NOT NULL DEFAULT '[]'::jsonb,
    status text NOT NULL CHECK (status IN ('draft','active','degraded','suspended','retired')),
    revision bigint NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sdar_control.management_operation (
    operation_id text PRIMARY KEY,
    operation_type text NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    status text NOT NULL CHECK (
      status IN ('accepted','running','succeeded','failed','canceled')
    ),
    idempotency_key text NOT NULL,
    actor_id text NOT NULL,
    reason text NOT NULL,
    result jsonb,
    error_code text,
    created_at timestamptz NOT NULL DEFAULT now(),
    completed_at timestamptz,
    UNIQUE (operation_type, idempotency_key)
);

CREATE TABLE sdar_control.control_audit_event (
    audit_id text PRIMARY KEY,
    actor_id text NOT NULL,
    action text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    expected_revision bigint,
    result_revision bigint,
    reason text NOT NULL,
    request_hash char(64) NOT NULL,
    result_code text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

-- Runtime database fresh-baseline additions.
-- These belong to the existing SDAR Runtime PostgreSQL database.

CREATE TABLE task_capability_binding (
    binding_id text PRIMARY KEY,
    task_id text NOT NULL UNIQUE REFERENCES agent_task(task_id),
    requested_capability_id text NOT NULL,
    capability_version bigint NOT NULL,
    exposure_id text,
    exposure_version bigint,
    input_snapshot jsonb NOT NULL,
    success_criteria_snapshot jsonb NOT NULL,
    evidence_requirement_snapshot jsonb NOT NULL,
    constraint_snapshot jsonb NOT NULL,
    initial_implementation_refs jsonb NOT NULL,
    provider_policy_snapshot jsonb,
    binding_hash char(64) NOT NULL,
    bound_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE task_capability_execution_attempt (
    attempt_id text PRIMARY KEY,
    task_id text NOT NULL REFERENCES agent_task(task_id),
    capability_binding_id text NOT NULL
      REFERENCES task_capability_binding(binding_id),
    attempt_no integer NOT NULL CHECK (attempt_no > 0),
    plan_id text,
    plan_template_ref text,
    skill_version_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    provider_binding_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    reason text NOT NULL CHECK (
      reason IN ('initial','replan','provider_failover','recovery','manual_change')
    ),
    status text NOT NULL CHECK (
      status IN ('prepared','running','waiting','succeeded',
                 'failed','canceled','superseded')
    ),
    started_at timestamptz,
    completed_at timestamptz,
    UNIQUE (task_id, attempt_no)
);

CREATE TABLE capability_readiness_snapshot (
    capability_id text NOT NULL,
    capability_version bigint NOT NULL,
    snapshot_version bigint NOT NULL,
    status text NOT NULL CHECK (
      status IN ('available','degraded','unavailable','suspended')
    ),
    evaluated_at timestamptz NOT NULL,
    valid_until timestamptz NOT NULL,
    catalog_hash char(64) NOT NULL,
    policy_hash char(64) NOT NULL,
    reasons jsonb NOT NULL,
    available_implementations jsonb NOT NULL,
    unavailable_implementations jsonb NOT NULL,
    PRIMARY KEY (capability_id, capability_version, snapshot_version)
);

CREATE TABLE runtime_agent_card_revision (
    revision bigint PRIMARY KEY,
    content jsonb NOT NULL,
    content_hash char(64) NOT NULL UNIQUE,
    capability_catalog_hash char(64) NOT NULL,
    status text NOT NULL CHECK (
      status IN ('staged','active','superseded','rejected')
    ),
    generated_at timestamptz NOT NULL,
    activated_at timestamptz
);
