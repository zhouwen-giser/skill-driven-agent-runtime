# 16. 部署、高可用与恢复设计

## 1. 首版拓扑

```text
Node Console
Node Control API
Node Control Worker
Control Plane PostgreSQL
SDAR Runtime
Runtime PostgreSQL
Redis/BullMQ
Telemetry Query Adapter
```

允许同机部署，但保持独立进程、数据库、凭据、日志和发布版本。

## 2. Control Plane 故障

Control Plane 停机时：

- Runtime 使用 Active/LKG 配置继续运行；
- 已运行任务继续；
- 现有 A2A Agent Card 使用 Runtime Active Revision；
- SMPP/MCP 在线调用继续；
- 新配置发布和治理写操作不可用。

## 3. Runtime 故障

Runtime 从 PostgreSQL 和既有 Recovery 恢复；Redis/BullMQ 仅作可重建协调。Control Plane 只显示 observed unavailable，不修改 Task 终态。

## 4. 数据库

- Control DB 和 Runtime DB 分开备份；
- v1.4 使用 Fresh Baseline；
- Production 禁止 Reset；
- Restore 后必须执行 Hash、Revision、Active Pointer 和 Runtime Reconciliation。

## 5. 配置缓存

Runtime 本地保存 Active/LKG 配置、Agent Card 和必要 Catalog。损坏 Revision 不覆盖 LKG。

## 6. 升级

升级步骤：预检 → 阻断不兼容新任务 → 备份 → Migration → 启动 → Readiness → 配置/Agent Card 对账 → 恢复流量。涉及 Task Authority 的切换禁止普通滚动双写。

## 7. 可用性目标

首版不承诺跨机自动 HA，但必须验证进程重启、Control Plane outage、Runtime restart、配置损坏、Registry outage 和 Telemetry outage。
