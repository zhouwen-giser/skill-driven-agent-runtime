# 13. Console 信息架构冻结基线

## 1. 顶层导航

```text
概览
配置发布
LLM 与模型路由
SMPP 服务
MCP Provider
Skill
Plan Template / Artifact
节点能力
A2A 暴露
任务与执行
遥测与对账
审计与运维
```

## 2. 概览

显示：

- Node Identity、Runtime Version、Control Contract Version；
- Desired/Observed Revision；
- Runtime、SMPP、MCP、LLM、Telemetry 健康；
- 已发布 Capability、可用/降级/不可用数量；
- 当前 Task、等待输入、等待外部、恢复和失败；
- 待应用配置和需要重启的 Revision。

概览不能根据 Telemetry 推断 Runtime terminal。

## 3. 配置发布

统一展示：

- Draft、Validation、Diff、Publish；
- Apply Mode；
- Runtime Ack；
- Active/LKG；
- Rollback-as-new-revision；
- Actor、Reason、Idempotency 和 Audit。

## 4. LLM 与模型路由

- Provider、Base URL、SecretRef 状态；
- Model Catalog；
- Structured Output、Tool Calling、Embedding 等能力；
- Stage Route 与 Fallback；
- Health、限流、成本和调用审计链接；
- 不显示明文 Credential。

## 5. SMPP 服务

分成两页：

### Registry Federation

- Source、Snapshot Revision、ETag、LKG、TTL；
- Provider Candidate；
- 同步历史和错误。

### ProviderOps 遥测

- 仅通过 SDAR Telemetry System 查询；
- 不提供 Provider 导入按钮；
- 明确显示“遥测不是注册或 Availability 权威”。

## 6. MCP Provider

三层状态：

```text
Candidate
→ Imported/Cataloged
→ Currently Available Resource
```

展示 SMPP 来源身份、Discover/Tools List、Catalog Drift、Availability、Remote Task 和 Provider Authority。

## 7. Skill

保留现有 Skill Studio：

- Package Validate/Import；
- Exact Version；
- Usage、Outcome、Evidence、Provider Policy；
- Enable/Suspend/Deprecate；
- Capability Implementation Binding；
- Execution History 通过 Runtime/Telemetry 查询。

## 8. Plan Template / Artifact

- P02/P08 权威版本；
- Candidate、Validation、Promotion、Active Pointer；
- Capability Binding；
- Materialization 和正式 Planner Handoff；
- 不能直接编辑运行中的 Workflow Instance。

## 9. 节点能力

一个页面四个视图：

1. Definition：业务承诺；
2. Implementation：Skill/Plan Template 绑定；
3. Readiness：Runtime 实时投影；
4. History：版本和变更。

Capability Summary 降为派生对照视图，不作为编辑入口。

## 10. A2A 暴露

- Exposure Version；
- AgentSkill ID；
- Request/Result Schema；
- Visibility/Requester Policy；
- Readiness Publication Policy；
- Agent Card Candidate/Applied Diff；
- 不显示内部 Skill/Provider 拓扑。

## 11. 任务与执行

- Task Capability Binding；
- Goal/Plan/Workflow；
- Execution Attempts；
- Skill/Provider 选择；
- Success/Evidence Snapshot；
- 受控 Pause/Resume/Cancel/Goal Patch；
- 不允许直接修改 Task phase。

## 12. 遥测与对账

通过独立 Telemetry Query API：

- Task Timeline；
- Capability 质量；
- ProviderOps 对账；
- Resource Health；
- 状态不一致；
- 数据水位与 DQ。

## 13. 审计与运维

- 配置和发布审计；
- Management Operations；
- Runtime Ack；
- SecretRef 健康；
- 备份、升级、重启和恢复；
- 所有危险操作要求二次确认。
