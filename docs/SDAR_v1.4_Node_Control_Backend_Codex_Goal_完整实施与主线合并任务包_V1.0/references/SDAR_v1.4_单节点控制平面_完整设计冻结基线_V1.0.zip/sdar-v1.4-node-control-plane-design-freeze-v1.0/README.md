# SDAR v1.4 单节点控制平面完整设计冻结基线 V1.0

## 冻结状态

- 状态：`DESIGN_FROZEN_IMPLEMENTATION_READY`
- 冻结日期：`2026-07-31`
- 目标产品：`SDAR v1.4 Single-Node Control Plane`
- 目标仓库：`zhouwen-giser/skill-driven-agent-runtime`
- v1.3 输入：主线任务完成（P00–P13）；P14 为可选发布后运维扩展，不构成 v1.4 阻断
- 数据策略：尚未正式发布，使用全新 v1.4 数据库基线，不兼容旧实验数据库
- 实施策略：设计、领域、协议、数据、安全、部署与验收基线全部冻结；源码精确 SHA 在首个实施 PR 前记录

## 产品定义

SDAR v1.4 将 v1.3 已完成的自治运行时升级为**可独立配置、发布、观察、升级和维护的标准自治节点产品**。

```text
Node Console
    ↓
Node Control Plane
    ├─ Node / LLM / SMPP / MCP 配置与版本发布
    ├─ Skill 与 Plan Template 治理入口
    ├─ Node Capability 唯一业务能力权威
    ├─ A2A Exposure 与 Agent Card 发布权威
    ├─ Desired State / Audit / Operation
    └─ Runtime 与 Telemetry 适配
          ↓
SDAR Runtime
    ├─ Goal / Task / Plan / Workflow / Skill Execution 权威
    ├─ Capability Resolution / Readiness / Task Binding
    ├─ LangGraph.js 唯一 Workflow Runtime
    └─ PostgreSQL 在线运行权威
          ↓
一个专属或多个共享 SMPP / MCP Provider Platform

SDAR Telemetry System
    └─ 独立采集、标准化、投影、ClickHouse、对账与分析
```

## 冻结的不变量

1. `NodeCapabilityDefinitionVersion` 是节点业务能力定义的唯一权威。
2. Skill 是能力的内部实现单元；P08 Plan Template Artifact 是流程模板唯一权威。
3. A2A 只发布 Capability Exposure，不直接发布内部 Skill。
4. Task 正式接受时原子创建不可变 `TaskCapabilityBinding`。
5. Capability Readiness 由 Runtime 确定性计算和持久化，控制面不能直接写状态。
6. Control Plane 表达期望状态；Runtime 维护执行权威；Telemetry 只读观察。
7. 已运行任务固定使用创建时的契约和版本快照；新版本默认只影响新任务。
8. SMPP Registry 是候选目录，`server/discover + tools/list` 是 Tool 权威，Availability 是资源执行权威。
9. 控制台不能直接修改 Task phase、Workflow Instance、Provider Task 或 ClickHouse 事实。
10. v1.4 不实现多节点组织编排，但发布标准 Node Management / Capability / Health / A2A 接口供后续组织平台使用。

## 目录

- `00-freeze-declaration.md`：冻结声明与变更控制
- `01-v1.3-final-input-baseline.md`：v1.3 最终输入和 P14 边界
- `02-product-scope-and-architecture.md`：产品范围与总体架构
- `03-domain-model.md`：领域聚合与关系
- `04-authority-and-state-machines.md`：权威、状态机与不变量
- `05-data-model.sql`：控制面与 Runtime 增量数据库基线
- `06-control-plane.openapi.yaml`：公开控制面 API
- `07-runtime-control-contract.yaml`：控制面—Runtime 内部协议
- `08-domain-events.yaml`：事件契约
- `09-configuration-and-versioning.md`：版本和生效语义
- `10-llm-provider-and-model-routing.md`：LLM 模块设计
- `11-smpp-and-mcp-provider-governance.md`：SMPP/MCP 模块设计
- `12-skill-capability-a2a-task-design.md`：核心能力链设计
- `13-console-information-architecture.md`：控制台信息架构
- `14-telemetry-integration-boundary.md`：遥测边界
- `15-security-rbac-and-secrets.md`：安全、权限和 Secret
- `16-deployment-availability-and-recovery.md`：部署、高可用和恢复
- `17-organization-platform-readiness.md`：分层组织平台预留
- `18-implementation-execplan.md`：实施批次
- `19-validation-and-release-gates.md`：验收与发布门禁
- `20-non-functional-requirements.md`：非功能基线
- `21-nonblocking-open-items.md`：非阻断待办
- `22-source-alignment.md`：来源对齐
- `contracts/`：RBAC、错误码、Apply Mode、Node API Profile
- `schemas/`：核心 JSON Schema
- `adr/`：架构决策记录
- `examples/`：契约示例
- `validation/`：机器自检
