# 11. SMPP 与 MCP Provider 治理设计

## 1. 在线发现链路

```text
1..N SMPP Registry API
→ Registry Federation
→ Snapshot/LKG
→ Provider Candidate
→ 批准导入
→ server/discover + tools/list
→ Local MCP Registry
→ Provider Policy
→ Availability
→ Tool / Remote Task
```

## 2. 权威分工

| 信息 | 权威 |
|---|---|
| Provider 候选目录 | SMPP Registry Snapshot |
| Tool Schema/Task Profile | 实时 Discover + Tools List |
| Resource 当前可执行性 | Availability |
| Remote Task 状态 | SDAR Runtime + Provider Task Authority 协议观察 |
| Provider 内部事实 | Provider Runtime/Adapter |
| 历史对账 | SDAR Telemetry System |

## 3. 来源身份

SMPP 来源必须使用：

```text
smppSourceId + externalProviderId + externalServerId
```

本地调用使用 `localServerId`，并保留 Registry Revision、Catalog Revision、Checksum。

## 4. Import 规则

- 默认人工或确定性策略批准；
- Telemetry 不得触发导入；
- Discover 或 Schema 校验失败不能进入 Active；
- Catalog Drift 生成事件并触发受影响 Capability Readiness 重算；
- Registry LKG 过期按 Source Policy fail closed；
- 一个节点可以连接多个 SMPP，一个 Provider 可以来自共享平台。

## 5. Provider Policy

Skill/Capability 不绑定具体 Resource；可以绑定 Operation、Provider Policy 和约束。运行时通过 Policy + Availability 选择 Provider/Resource，并把选择写入 Attempt 快照。

## 6. 失败隔离

- 单一 SMPP 不可用不影响其他 Source；
- 单一 Provider 不可用只影响相关实现路径；
- Telemetry/ClickHouse 不可用不影响在线发现和执行；
- Control Plane 不可用时 Runtime 继续使用 Active/LKG Registry 与本地 Catalog。
