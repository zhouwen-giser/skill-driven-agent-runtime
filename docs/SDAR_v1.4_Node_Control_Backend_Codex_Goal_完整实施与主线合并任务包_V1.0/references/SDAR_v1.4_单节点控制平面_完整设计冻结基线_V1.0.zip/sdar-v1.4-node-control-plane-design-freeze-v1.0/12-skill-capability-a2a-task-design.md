# 12. Skill—Capability—A2A—Task 核心设计

## 1. 核心链路

```text
Provider Operation
→ Skill Version
→ Plan Template Artifact Version
→ Capability Implementation Binding
→ Node Capability Version
→ A2A Exposure Version
→ Agent Card Revision
→ A2A/Internal Task
→ Task Capability Binding
→ Execution Attempt
```

## 2. Skill

Skill 是内部可复用执行方法，保留现有 Usage、Outcome、Evidence、Provider Policy、Composition 和 Exact Version 机制。自由字符串 `capabilities[]` 不再是正式能力权威。

## 3. Plan Template

P08 Plan Template Artifact 是可复用流程模板唯一权威；Capability 绑定其精确版本。物化后进入现有 Planner/Workflow，不创建第二套 Runtime。

## 4. Node Capability

Capability 表达节点可以承诺的业务结果，包括输入、输出、成功条件、必要证据、约束、效果、风险和支持模式。Published Version 不可修改。

## 5. Implementation Binding

支持 `primary / alternative / supporting / validation / recovery`。一个 Capability 可有多个实现；一个 Skill/Template 可支持多个 Capability。

## 6. Readiness

Runtime 对每个 Published Capability 进行事件驱动确定性计算：

```text
Definition Published
+ Implementation valid
+ Skill/Template active
+ Provider Catalog compatible
+ Availability fresh
+ LLM/Policy dependency available
= available / degraded / unavailable / suspended
```

短时抖动使用 TTL、迟滞和最后已知状态策略。

## 7. A2A Exposure

内部 Capability 通过 Exposure 投影为 A2A `AgentSkill`。Exposure 控制名称、描述、Schema、模态、可见范围、请求者策略和 Readiness 发布策略。不得泄漏内部 Skill、Provider、Plan Template 和失败统计。

## 8. Task Acceptance

```text
A2A Message / Internal Goal
→ Capability Resolution
→ Exposure/Requester Policy
→ Readiness Check
→ Input Validation
→ Task Accept Transaction
   ├─ AgentTask accepted
   ├─ TaskCapabilityBinding immutable snapshot
   └─ initial transition/outbox
```

歧义进入 `input-required`；高风险能力执行既有确认与 Policy。

## 9. Replan / Failover

原始 TaskCapabilityBinding 不变。每次重规划、Provider Failover 或 Recovery 创建新的 Execution Attempt，记录 Plan、Skill、Provider 和原因。

## 10. 完成判定

```text
Workflow/Skill execution terminal
AND Capability success criteria satisfied
AND required evidence complete
AND safety/authorization policy satisfied
→ Task terminal success
```

Provider terminal、Telemetry Fact 或 Tool 返回不能单独完成 A2A Task。
