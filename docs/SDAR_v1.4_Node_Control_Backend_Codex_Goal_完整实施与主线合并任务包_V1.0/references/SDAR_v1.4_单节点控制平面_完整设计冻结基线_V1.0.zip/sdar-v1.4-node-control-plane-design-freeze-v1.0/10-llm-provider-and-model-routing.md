# 10. LLM Provider 与 Model Routing 模块设计

## 1. 权威

- Control Plane：Provider Definition、Model Catalog、Stage Route Desired Revision；
- Runtime：实际 Client、健康、路由选择、Invocation 和降级执行；
- Telemetry：历史延迟、Token、成本、错误和质量分析。

## 2. 核心对象

```text
LlmProviderDefinition
LlmModelDefinition
ModelStageRouteRevision
ModelFallbackChain
RuntimeModelRouteAck
```

## 3. 必要字段

- providerType、baseUrl、credentialRef；
- modelId、capability flags、context window；
- toolCalling、structuredOutput、vision、embedding；
- timeout、retry、rateLimit、budget；
- route stage、priority、fallback；
- health policy 和 circuit breaker。

## 4. 生效规则

- Provider Endpoint/Credential：`reconnect_required`；
- Stage Route/Fallback：`new_task_only`；
- 限流和预算：可按定义 `hot_reload`；
- 运行中 LLM 调用不切换模型；下一个可恢复步骤按 Task Snapshot 或显式 Recovery Policy 处理。

## 5. 安全

- API、日志、审计和遥测不得返回 Secret；
- Secret 只保存 SecretRef；
- 健康检查不得泄漏上游响应正文；
- 用户输入不能控制 baseUrl、credentialRef 或模型安全策略。

## 6. Console

支持 Provider、Model Catalog、Stage Route、Fallback、健康、Revision Diff 和 Runtime Ack；调用明细跳转独立 Telemetry Query。
