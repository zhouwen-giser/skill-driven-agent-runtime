# 17. 分层自治组织平台预留基线

## 1. v1.4 的定位

v1.4 只管理一个 SDAR 节点，不实现 Parent/Child 组织树、跨节点资源仲裁和全局目标编排。

## 2. 必须发布的标准接口

```text
Node Identity
Node Health
Node Capability Catalog
Capability Readiness
A2A Agent Card
Goal/Task submission
Task status and evidence summary
Configuration revision summary
Version and compatibility profile
```

组织平台通过标准 API/A2A 使用节点，不读取节点数据库，也不理解内部 Skill/Workflow/Provider 结构。

## 3. 权限预留

NodeProfile 预留 `organizationBindingRef` 只读投影；Authority Scope 和 Requester Policy 支持未来组织身份，但 v1.4 不维护组织权威。

## 4. Provider 化组织连接

后续可用 SDAR Node Provider/Adapter 将下级 SDAR 的 A2A Capability 包装成上级稳定任务通道。v1.4 的 Capability、Exposure、Task Binding 和版本模型必须保持可复用。

## 5. 禁止事项

- 不在 v1.4 Control DB 建组织树；
- 不把上级目标直接写进节点运行表；
- 不让组织平台绕过 Node Policy 或 Task Acceptance；
- 不让组织平台直接选择节点内部 Skill/Provider。
