# 15. 安全、RBAC 与 Secret 基线

## 1. 角色

- `node_admin`：节点定义、配置发布、能力和 A2A 管理；
- `node_operator`：运行观察、受控暂停/恢复/取消、同步与健康操作；
- `node_viewer`：只读；
- `security_admin`：CredentialRef、策略、审计；
- `runtime_service`：Pull/Watch/Ack；
- `organization_service`：未来只读能力/健康及受控目标接口。

详见 `contracts/rbac-matrix.csv`。

## 2. Secret

- 领域对象只保存 SecretRef；
- Control Plane 和 Runtime 使用不同 Service Credential；
- Console 不提供 Secret 回读；
- Audit/Telemetry/Problem Detail 必须脱敏；
- Provider/LLM Endpoint 实施 Scheme、Host/CIDR 和 TLS 策略。

## 3. 写操作保护

所有写操作必须具备认证、授权、Expected Revision、Idempotency Key、Reason 和 Audit。高风险操作要求二次确认。

## 4. Prompt Injection 边界

来自 Provider、Skill 文档、Artifact、Telemetry 和日志的文本均为不可信数据，不能改变系统指令、权限、Endpoint 或执行策略。

## 5. 供应链

- Skill/Artifact/Provider Package 必须有 Hash、版本和验证状态；
- 禁止在线下载并执行任意代码；
- v1.4 首版采用允许列表和已登记包；
- 依赖、镜像和 SBOM 纳入发布门禁。

## 6. 审计

记录 Actor、Action、Target、Before/After Hash、Reason、Idempotency、Expected/Result Revision、Result Code、Trace 和时间。审计不可由普通管理员修改。
