# 04. 权威边界、状态机与不变量

## 1. 权威矩阵

| 数据/行为 | 权威 |
|---|---|
| Node Profile、配置 Revision、Capability Definition、Exposure Definition | Node Control Plane PostgreSQL |
| SkillVersion、Skill Usage、Skill Outcome、Skill 发布状态 | SDAR Runtime PostgreSQL |
| Plan Template Artifact Version、Pointer、Promotion | SDAR Artifact Runtime/PostgreSQL |
| Goal、Task、Plan、Workflow Instance、Skill Execution | SDAR Runtime PostgreSQL |
| TaskCapabilityBinding、TaskExecutionAttempt | SDAR Runtime PostgreSQL |
| Capability Readiness | SDAR Runtime PostgreSQL 运行投影 |
| Agent Card Active Revision | SDAR Runtime PostgreSQL 本地应用快照 |
| SMPP Registry Candidate Snapshot | Node Control Plane LKG |
| MCP Tool Catalog | SDAR Runtime 实时 Discover/Tools List 后的本地 Registry |
| Resource Availability | 在线 Provider Availability |
| Provider Task/Command | SMPP Runtime Database |
| 历史分析、外部 ProviderOps、跨系统对账 | SDAR Telemetry System |
| Redis/BullMQ | 可重建调度和短期协调，不是权威 |

## 2. Definition 与 Applied Snapshot

```text
Control Plane Definition
→ Published Revision
→ Runtime Pull
→ Validate/Staging
→ Apply
→ Runtime Ack
→ Active/LKG Snapshot
```

- Publish 不等于 Apply；
- Runtime 可以拒绝不兼容、陈旧或不安全 Revision；
- Control Plane 不可直接写 Runtime 权威表；
- Runtime 冷启动使用本地 Bootstrap + LKG；
- Control Plane 不可用不影响已应用版本和已运行任务。

## 3. Capability 状态机

```text
draft
→ validating
→ published
→ suspended
→ published
→ deprecated
→ retired
```

规则：

- `published` Version 不可编辑；
- `deprecated` 允许已有任务继续，不接受新绑定；
- `suspended` 暂停新任务，保留历史；
- `retired` 不允许重新启用，只能创建新 Version。

## 4. A2A Exposure 状态机

```text
draft
→ published
→ suspended
→ published
→ retired
```

Exposure 发布触发 Agent Card Candidate 生成；Runtime 应用成功后才切换 Active Card。

## 5. Configuration Revision 状态机

```text
draft
→ validated
→ published
→ applying
→ applied
             ↘ partially_applied
             ↘ rejected
applied/partially_applied
→ rolled_back（通过发布前一内容的新 Revision）
```

不原地修改已发布内容。

## 6. Capability Readiness 状态

```text
available
degraded
unavailable
suspended
```

变化触发条件：

- Capability/Binding/Skill/Artifact 发布状态变化；
- MCP Catalog Revision 变化；
- Availability 新鲜度变化；
- Model Route/LLM 健康变化；
- Policy/Kill Switch 变化；
- Node maintenance 状态变化。

短时 Availability 波动使用 TTL、迟滞和最小稳定窗口，不直接频繁改 Agent Card。

## 7. Task 接受不变量

Task 只有满足以下条件才能正式接受：

1. Capability 已解析且版本已发布；
2. Exposure 存在时已发布且请求方满足策略；
3. Readiness 不为 unavailable/suspended；
4. Input Schema 通过；
5. 风险、权限和确认要求已满足；
6. `TaskCapabilityBinding` 与 Task 在同一 PostgreSQL 事务内创建；
7. 相同 Task 只能存在一个初始 Capability Binding。

## 8. 运行中变化不变量

- Capability 新版本不改变旧 Task；
- Skill/Plan Template 新版本不替换运行中 Attempt；
- Provider Failover 创建新 Attempt，不覆盖历史；
- Goal Patch 继续遵循现有“旧 Plan/Workflow 失效、新版本重建”规则；
- Terminal Judge 使用 TaskCapabilityBinding 的成功条件和证据快照；
- Provider terminal 不能单独完成 A2A Task；
- Telemetry mismatch 只能产生告警/Incident，不能写 Task terminal。

## 9. 安全基线

- Node Control Plane 写接口必须认证；
- 首版单节点、单租户；组织平台的多租户隔离不在 v1.4 范围；
- Secret 只以 `SecretRef` 进入领域对象；
- Runtime 和 Console 永不回读明文 Secret；
- Control Plane 对 Runtime 使用独立 Service Credential；
- 所有写操作具有 Actor、Reason、Idempotency Key、Expected Revision 和 Audit。
