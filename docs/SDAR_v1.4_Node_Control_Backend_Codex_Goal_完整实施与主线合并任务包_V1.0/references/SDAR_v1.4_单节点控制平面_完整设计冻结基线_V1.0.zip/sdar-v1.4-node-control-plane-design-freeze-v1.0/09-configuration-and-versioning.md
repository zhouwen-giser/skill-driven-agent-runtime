# 09. 配置、版本与生效语义

## 1. 统一生命周期

```text
Draft → Validate → Publish → Apply/Staging → Ack → Active/LKG
                                      └→ Rejected / Restart Required
Rollback = 发布一个引用历史内容的新 Revision
```

所有已发布内容不可修改；任何变化创建新 Revision。

## 2. Apply Mode

| 模式 | 语义 | 示例 |
|---|---|---|
| `hot_reload` | 在线原子切换 | 日志级别、部分限流、采样 |
| `new_task_only` | 只影响新 Task | Model Route、Capability、Skill、Plan Template |
| `reconnect_required` | 重建外部 Client | SMPP Watch、部分 Provider Endpoint |
| `restart_required` | Runtime 安全重启 | 数据库、监听端口、核心启动参数 |
| `immutable` | 发布后不可变 | nodeId、Task Authority Identity、bindingId |

## 3. 版本规则

- 业务定义使用 `(id, version)`；
- 配置使用 `(configurationId, revision)`；
- 外部快照同时保存 `revision + checksum`；
- Task 使用不可变契约快照，不依赖“当前版本”；
- Readiness 使用 `snapshotVersion + validUntil`；
- Agent Card 使用单调 Revision 和内容 Hash。

## 4. 并发和幂等

所有写操作要求：

```text
Idempotency-Key
If-Match / expectedRevision
actorId
reason
requestHash
```

同 Key + 同 Request Hash 返回原结果；同 Key + 不同请求必须拒绝。

## 5. Desired / Observed

Control Plane 保存 Desired；Runtime Ack 形成 Observed。`Published != Applied`，`PM2 online != Runtime ready`，`Telemetry present != Runtime state`。

## 6. 运行中任务

- 新版本默认只影响新任务；
- 运行中任务引用 TaskCapabilityBinding、Plan Revision、Skill Attempt 和 Provider Selection 快照；
- 显式迁移必须形成新的 Management Operation、预检、审计和补偿计划；
- v1.4 首版不提供通用运行中版本迁移。
