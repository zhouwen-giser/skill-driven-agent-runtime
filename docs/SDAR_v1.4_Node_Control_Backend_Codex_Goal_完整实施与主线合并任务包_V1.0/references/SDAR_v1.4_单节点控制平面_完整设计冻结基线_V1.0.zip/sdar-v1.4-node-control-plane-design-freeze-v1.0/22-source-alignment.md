# 22. 来源与仓库对齐

## 1. 仓库

```text
repository: zhouwen-giser/skill-driven-agent-runtime
v1.3 branch/ref: feature/v1.3-sequential-implementation（用户确认主线完成）
formal v1.3 packages: P00-P13
optional extension: P14 / X01 / Post-Release Operations
```

## 2. 冻结接口输入

- SDAR v1.3 Frozen Cross-package Interface Registry V1.1；
- Artifact Types：intent_route、plan_template、decision_rule、case_template、model_route；
- HandoffEnvelope V1.1；
- v1.3 P13 Release Candidate Audit；
- v1.3 P14 Optional Operations Summary；
- v1.4 V0.1 预设计和 V1.0 设计基线；
- SMPP Registry Federation / ProviderOps Telemetry V1.2；
- SMPP Provider Platform V1.0。

## 3. 源码级对齐门禁

GitHub App 当前未暴露 `skill-driven-agent-runtime` 仓库，因此本次以用户确认和冻结设计资产完成语义冻结。实施前必须在本地仓库自动生成：

- `SOURCE-BASELINE.json`；
- `RUNTIME-SYMBOL-MAP.csv`；
- `OPENAPI-OPERATION-INVENTORY.json`；
- `MIGRATION-HEAD.txt`；
- `PACKAGE-VERSION.txt`。

如果符号名称变化，由 Adapter 映射解决；若业务语义与本基线冲突，必须停止并提交 ADR，不允许静默偏移。
