# 02. 产品范围与总体架构

## 1. 产品目标

v1.4 的直接产品是一个可独立交付的 SDAR 节点：管理员无需修改源码或直接操作数据库，即可配置 LLM、SMPP、MCP Provider、Skill、Plan Template、Capability、A2A 暴露和节点运行策略，并观察 Runtime 与独立遥测系统的状态。

## 2. 总体架构

```mermaid
flowchart TB
  U[管理员 / 运维人员] --> C[Node Console]
  C --> CP[Node Control Plane]
  CP --> CDB[(Control Plane PostgreSQL)]
  CP --> RC[Runtime Control Client]
  RC --> RT[SDAR Runtime]
  RT --> RDB[(Runtime PostgreSQL)]
  RT --> SMPP[SMPP Registry Federation]
  RT --> MCP[MCP Tool / Remote Task]
  MCP --> PP[专属或共享 MCP Provider Platform]
  RT --> TE[Telemetry Export / Event Outbox]
  TE --> TS[SDAR Telemetry System]
  TS --> CH[(ClickHouse / Object Storage)]
  C --> TQA[Telemetry Query Adapter]
  TQA --> TS
  CP -.未来标准 Node API.-> ORG[Autonomous Organization Control Platform]
```

## 3. v1.4 内部范围

- Node Profile；
- Configuration Revision；
- LLM Provider 与 Model Route 治理；
- SMPP Registry Source 与 LKG；
- MCP Provider Candidate / Binding / Catalog；
- Skill 与 Plan Template 的统一治理入口；
- Node Capability Definition / Implementation / Readiness；
- A2A Exposure / Agent Card Revision；
- Task Capability Binding 与 Execution Attempt 查询；
- Console、Audit、Operation、Backup/Restore/Upgrade；
- Runtime/Telemetry Adapter。

## 4. 明确非目标

- 不实现多 SDAR 组织树和跨节点编排；
- 不实现全局监督纠错系统；
- 不实现全域交互中枢；
- 不重写 LangGraph Workflow Runtime；
- 不把遥测采集、投影或 ClickHouse 写入放进 SDAR 仓库；
- 不管理 Provider Adapter 内部设备协议；
- 不让 Control Plane 直接修改运行中 Task/Workflow；
- 不兼容旧实验数据库。

## 5. 产品依赖

| 依赖 | 使用方式 | 失败影响 |
|---|---|---|
| SDAR Runtime | 在线运行权威 | Control Plane 可降级只读/不可写 |
| SMPP Registry | 候选 Provider 目录 | 使用未过期 LKG 或 fail closed |
| MCP Provider | Tool/Task 执行 | Readiness 降级，不影响其他实现 |
| Telemetry System | 历史/分析/对账 | 在线任务不受影响 |
| Secret Store | CredentialRef 解析 | 受影响配置不可应用 |
