# 14. SDAR Telemetry System 集成边界

## 1. 完全独立

SDAR Runtime 与遥测系统分离。SMPP ProviderOps 的采集、标准化、关系构建、投影、ClickHouse 入库和对账也统一属于 SDAR Telemetry System。

## 2. 数据链路

```text
SDAR Runtime / SMPP Runtime / Adapter / Device
→ Event/OTLP/ProviderOps Outbox
→ Telemetry Ingestion + WAL
→ Canonical Fact / Relation Fact
→ Projection Registry
→ ClickHouse / Object Storage
→ Query / Reconciliation API
```

## 3. 在线权威与遥测权威

- Runtime PostgreSQL：Goal/Task/Workflow/Skill/Remote Task 在线权威；
- SMPP Runtime DB：Provider Task/Command/Scheduler/Recovery 权威；
- ClickHouse：分析、历史、外部事实和对账；
- Telemetry mismatch：告警或 Incident 输入，不能直接修改在线状态。

## 4. Node Console 接入

Console 不直连 ClickHouse。通过 Telemetry Query Adapter 请求：

- Task/Skill/Workflow 时间线；
- ProviderOps 对账；
- Capability 质量与 Readiness 历史；
- LLM 延迟、成本和错误；
- Resource Health；
- 数据水位和 DQ。

## 5. 故障隔离

Telemetry、Collector、ClickHouse 或 Query API 不可用时：

- Runtime 继续执行；
- A2A Agent Card 和 Readiness 继续读取 Runtime 在线投影；
- Provider Registry 和 Availability 不受影响；
- Console 明确显示历史分析不可用，不伪造状态。
