# 00. v1.4 完整设计冻结声明

## 1. 冻结结论

本设计包状态为 `DESIGN_FROZEN_IMPLEMENTATION_READY`。从 2026-07-31 起，v1.4 的产品边界、领域权威、主要聚合、状态机、数据分层、协议方向、安全边界、实施顺序和验收规则进入受控变更。

## 2. v1.3 输入状态

- v1.3 正式任务范围：P00–P13；
- 用户确认：主要任务已经完成，主线完成；
- P14：`Optional Post-Release Operations`，非正式包、扩展目标 X01；
- P14 不阻塞 v1.4 的领域、协议、数据库和 Console 设计；
- P14 后续可提供部署运维、Runbook、发布后操作资产，由 v1.4 的运维模块吸收。

## 3. 冻结层级

| 层级 | 状态 | 允许变更 |
|---|---|---|
| 产品范围 | 冻结 | 仅重大 ADR |
| 权威边界 | 冻结 | 不允许由字段适配改变 |
| 领域聚合 | 冻结 | 可增加非破坏字段，新增聚合需 ADR |
| 状态机 | 冻结 | 新状态需 ADR + 全链路测试 |
| OpenAPI 主资源与动作 | 冻结 | 字段细化允许，删除/改语义禁止 |
| Runtime 内部协议 | 冻结 | 源码符号映射允许 |
| 数据模型 | 设计冻结 | 实施时可调整类型/索引，不可改变权威 |
| Console IA | 冻结 | 视觉与交互细节允许 |
| 实施批次 | 冻结 | 允许拆细，不允许越过依赖 |

## 4. 变更控制

任何改变以下内容的提议必须新增 ADR：

- Capability 唯一权威；
- Plan Template / Workflow 模板权威；
- A2A Exposure 投影来源；
- TaskCapabilityBinding 创建时机或可变性；
- Runtime/Control Plane/Telemetry 权威边界；
- SMPP Registry、Catalog、Availability 的权威分工；
- 数据库兼容策略；
- Node Control Plane 是否独立部署；
- 组织平台是否进入 v1.4 范围。

## 5. 实施前唯一硬性来源门禁

首个 v1.4 实施 PR 前必须记录：

```text
repository
v1.3 final branch/ref
exact baseline SHA
migration head
package/version
OpenAPI operation inventory hash
Frozen Interface Registry version/hash
```

该门禁用于可追溯性，不重新开启领域设计。
