# 18. SDAR v1.4 单节点控制平面冻结 ExecPlan

## Purpose / Outcome

完成后，一个 SDAR 节点能够通过独立 Console 和 Control Plane 完成配置、能力接入、Skill/Plan Template 治理、A2A 能力发布、任务能力追踪和运行观察；Control Plane 离线时 Runtime 继续使用 LKG 自治运行。

## Requirements Covered

- 单节点独立配置和运维；
- LLM Provider 与 Model Route；
- 一个或多个 SMPP Registry Source；
- MCP Provider Candidate/Import/Catalog/Availability；
- Skill 注册与发布入口；
- Plan Template Artifact 调整；
- Capability—Skill—Plan Template—A2A—Task 完整关系；
- 独立 Telemetry Query 接入；
- 版本、审计、恢复和组织平台预留。

## Context and Orientation

- `packages/domain`：现有 Runtime Domain；
- `packages/application`：现有 Skill/Task/Artifact/Model/MCP 应用权威；
- `packages/management-api`：现有 Runtime Operational API；
- `apps/console`：现有 Console；
- `packages/a2a-adapter`：A2A wire 投影；
- `packages/persistence-postgres`：Runtime 权威；
- P02/P08：Artifact/Plan Template 权威；
- LangGraph.js：唯一 Workflow Runtime。

## Architecture and Interfaces

新增建议：

```text
apps/node-control-api
apps/node-control-worker
apps/node-console（或现有 Console 迁入）
packages/node-control-domain
packages/node-control-application
packages/node-control-persistence-postgres
packages/runtime-control-client
packages/smpp-registry-adapter
packages/telemetry-query-adapter
```

Runtime 内新增：

```text
packages/domain/src/capability-contract.ts
packages/application/src/capability-runtime.ts
packages/persistence-postgres/src/task-capability-repository.ts
packages/a2a-adapter/src/capability-exposure-projection.ts
```

## Implementation Steps

### P0 来源锁、基线导入与独立骨架

- 建立 ADR、Schema、OpenAPI 和 Contract Fixtures；
- 建立 Control Plane 独立进程和数据库；
- Node Profile、Management Operation、Audit；
- 验证 Control Plane 停机不影响 Runtime。

### P1 Configuration Revision

- Draft/Validate/Publish/Ack/LKG；
- Runtime Config Client；
- Apply Mode；
- Revision Watch 和 ETag；
- 故障与损坏 Revision 回退。

### P2 LLM Provider / Model Route

- SecretRef；
- Provider/Model Catalog；
- Route/Fallback；
- 新任务生效；
- Runtime Ack 和健康。

### P3 SMPP Registry Federation

- 多 Source；
- Bootstrap/Latest/Watch/LKG；
- Candidate 目录；
- `smpp_source_id` 身份隔离；
- 不接入 Telemetry 决策。

### P4 MCP Provider Binding

- Candidate Import；
- Discover/Tools List；
- Catalog Snapshot；
- Availability；
- Direct/SMPP 来源；
- Catalog Drift。

### P5 Capability Definition / Implementation

- Capability Version；
- Skill/Plan Template Binding；
- Publish Validation；
- Catalog Apply；
- 清理旧自由字符串 Capability 权威。

### P6 A2A Exposure

- Exposure Version；
- Agent Card Revision；
- Capability-only AgentSkill；
- Requested Capability metadata；
- A2A TCK 和隐私过滤。

### P7 Task Capability Binding / Readiness

- Task 接受事务；
- Readiness Snapshot；
- Attempt History；
- Terminal Success/Evidence Judge；
- Replan/Failover 历史。

### P8 Console Integration

- 统一导航；
- Desired/Observed；
- 四视图 Capability；
- A2A Card Diff；
- Runtime/Telemetry Adapter。

### P9 Security / Backup / Upgrade

- Control Plane Authentication；
- Service Credential；
- SecretRef；
- Backup/Restore；
- Fresh Baseline Migration Gate；
- Upgrade/Restart runbook。

## Validation

每个阶段运行最小门禁；最终必须运行：

```text
pnpm format:check
pnpm lint
pnpm typecheck
pnpm test:unit
pnpm test:contract
pnpm test:integration
pnpm test:e2e
pnpm verify:architecture
pnpm verify:management-openapi
pnpm verify:a2a-baseline
pnpm test:a2a-tck
pnpm build
pnpm smoke
pnpm verify
```

新增必须验证：

- Control Plane DB fresh create；
- Runtime DB fresh create；
- Control Plane outage；
- corrupted revision/LKG；
- concurrent publish/CAS；
- Task atomic capability binding；
- A2A capability exposure；
- Provider Availability freshness；
- Telemetry outage non-impact；
- restart/reconciliation。

## Idempotence and Recovery

- 所有写操作使用 Idempotency Key；
- Revision 内容不可变；
- Publish/Apply/Ack 可重复；
- Runtime 从 LKG 启动；
- Redis 丢失从 PostgreSQL 重建必要调度；
- 失败 Revision 不覆盖 Active；
- 新版本只影响新 Task。

## Artifacts and Evidence

- ADR；
- OpenAPI/JSON Schema；
- Migration；
- Contract fixtures；
- Unit/Integration/E2E；
- A2A TCK；
- outage/recovery report；
- Console screenshots；
- Traceability Matrix；
- release report。
