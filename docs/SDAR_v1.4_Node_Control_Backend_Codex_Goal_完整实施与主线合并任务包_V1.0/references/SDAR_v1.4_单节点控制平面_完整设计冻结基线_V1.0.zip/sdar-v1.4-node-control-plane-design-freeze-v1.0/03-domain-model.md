# 03. 领域模型冻结基线

## 1. 总体关系

```mermaid
flowchart LR
    SMPP[SMPP Registry Source]
    MPB[MCP Provider Binding]
    OP[Provider Operation]
    SK[Skill Version]
    PT[Plan Template Artifact Version]
    CAP[Node Capability Version]
    IMPL[Capability Implementation Binding]
    RD[Capability Readiness Snapshot]
    EXP[A2A Exposure Version]
    CARD[Agent Card Revision]
    T[Agent Task]
    TCB[Task Capability Binding]
    ATT[Task Execution Attempt]

    SMPP --> MPB
    MPB --> OP
    OP --> SK
    SK --> IMPL
    PT --> IMPL
    IMPL --> CAP
    CAP --> RD
    CAP --> EXP
    EXP --> CARD
    CARD --> T
    T --> TCB
    TCB --> CAP
    TCB --> EXP
    TCB --> ATT
    ATT --> SK
    ATT --> PT
    ATT --> MPB
```

## 2. 聚合与权威

### 2.1 NodeProfile

节点稳定身份。

```ts
interface NodeProfile {
  nodeId: string;
  nodeType: string;
  displayName: string;
  description: string;
  environment: string;
  labels: Record<string, string>;
  authorityScopes: string[];
  runtimeEndpointRef: string;
  telemetryEndpointRef?: string;
  status: 'draft' | 'active' | 'maintenance' | 'retired';
  revision: number;
}
```

不变量：

- `nodeId` 发布后不可变；
- 一个控制面实例只管理一个 `nodeId`；
- 组织关系不进入 v1.4 NodeProfile 权威，只预留只读 `organizationBindingRef`。

### 2.2 ConfigurationRevision

```ts
type ApplyMode =
  | 'hot_reload'
  | 'new_task_only'
  | 'reconnect_required'
  | 'restart_required'
  | 'immutable';

interface ConfigurationRevision {
  configurationId: string;
  targetType:
    | 'node'
    | 'llm_provider'
    | 'model_route'
    | 'smpp_source'
    | 'mcp_provider_binding'
    | 'telemetry_link'
    | 'runtime_policy';
  targetId: string;
  revision: number;
  status:
    | 'draft'
    | 'validated'
    | 'published'
    | 'applying'
    | 'applied'
    | 'partially_applied'
    | 'rejected'
    | 'rolled_back';
  applyMode: ApplyMode;
  content: unknown;
  checksum: string;
  createdBy: string;
  createdAt: string;
}
```

### 2.3 LlmProviderDefinition

控制面管理供应商、模型目录和 SecretRef；Runtime 继续拥有实际模型调用和 Invocation Audit。

```ts
interface LlmProviderDefinition {
  providerId: string;
  providerType: string;
  baseUrl: string;
  credentialRef: string;
  models: LlmModelDefinition[];
  healthPolicy: unknown;
  rateLimitPolicy: unknown;
  status: 'draft' | 'active' | 'degraded' | 'suspended' | 'retired';
  revision: number;
}
```

### 2.4 SmppRegistrySource

```ts
interface SmppRegistrySource {
  smppSourceId: string;
  name: string;
  registryEndpoint: string;
  credentialRef: string;
  environment: string;
  tenantId?: string;
  projectId?: string;
  syncMode: 'manual' | 'poll' | 'watch';
  snapshotTtlSeconds: number;
  lkgPolicy: 'allow_unexpired' | 'deny_when_unavailable';
  status: 'draft' | 'active' | 'suspended' | 'retired';
  revision: number;
}
```

### 2.5 McpProviderBinding

```ts
interface McpProviderBinding {
  bindingId: string;
  localServerId: string;
  originType: 'direct' | 'smpp_registry';
  smppSourceId?: string;
  externalProviderId?: string;
  externalServerId?: string;
  registryRevision?: number;
  registryChecksum?: string;
  catalogRevision: string;
  catalogChecksum: string;
  endpointRef: string;
  status:
    | 'candidate'
    | 'imported'
    | 'active'
    | 'degraded'
    | 'suspended'
    | 'removed';
  revision: number;
}
```

Registry Snapshot 是候选目录；正式 Tool 权威是实时 `server/discover + tools/list`；Resource 可执行性权威是 Availability。

### 2.6 NodeCapabilityDefinitionVersion

```ts
interface NodeCapabilityDefinitionVersion {
  capabilityId: string;
  version: number;
  domain: string;
  name: string;
  description: string;
  inputSchema: JsonSchema;
  outputSchema: JsonSchema;
  successCriteria: CapabilityCriterion[];
  requiredEvidence: CapabilityEvidenceRequirement[];
  effects: string[];
  artifacts: string[];
  constraints: CapabilityConstraint[];
  supportedModes: string[];
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  status:
    | 'draft'
    | 'validating'
    | 'published'
    | 'suspended'
    | 'deprecated'
    | 'retired';
  definitionHash: string;
  previousVersion?: number;
  createdBy: string;
  createdAt: string;
}
```

不变量：

1. Published Version 不可修改。
2. Published 前至少有一个 `primary` 或 `alternative` 实现路径。
3. Capability 不直接绑定具体 Resource。
4. 成功条件和证据要求必须结构化、可快照。
5. 高风险和关键能力必须显式声明约束与人工确认策略。

### 2.7 CapabilityImplementationBinding

```ts
interface CapabilityImplementationBinding {
  bindingId: string;
  capabilityId: string;
  capabilityVersion: number;
  implementationType: 'skill' | 'plan_template';
  implementationId: string;
  implementationVersion: string;
  role:
    | 'primary'
    | 'alternative'
    | 'supporting'
    | 'validation'
    | 'recovery';
  priority: number;
  activationCondition?: unknown;
  providerPolicyOverride?: unknown;
  status: 'draft' | 'active' | 'suspended' | 'retired';
  revision: number;
}
```

禁止 `workflow_template` 类型；流程模板统一使用 Plan Template Artifact。

### 2.8 CapabilityReadinessSnapshot

运行权威位于 Runtime。

```ts
interface CapabilityReadinessSnapshot {
  capabilityId: string;
  capabilityVersion: number;
  snapshotVersion: number;
  status: 'available' | 'degraded' | 'unavailable' | 'suspended';
  evaluatedAt: string;
  validUntil: string;
  catalogHash: string;
  policyHash: string;
  reasons: CapabilityReadinessReason[];
  availableImplementations: string[];
  unavailableImplementations: string[];
}
```

Readiness 计算输入：

- Capability/Binding 已发布；
- Plan Template/Skill 精确版本可用；
- Provider Catalog 与 Schema 匹配；
- Availability 新鲜；
- LLM/模型路由满足；
- 安全、策略、权限和 Kill Switch 允许；
- 节点没有进入 maintenance/suspended。

### 2.9 A2AExposureVersion

```ts
interface A2AExposureVersion {
  exposureId: string;
  version: number;
  capabilityId: string;
  capabilityVersion: number;
  agentSkillId: string;
  name: string;
  description: string;
  tags: string[];
  examples: string[];
  inputModes: string[];
  outputModes: string[];
  requestSchema: JsonSchema;
  resultSchema: JsonSchema;
  visibility: 'organization' | 'public';
  requesterPolicy: unknown;
  readinessPublicationPolicy:
    | 'publish_when_available'
    | 'publish_degraded'
    | 'always_publish_with_status';
  status: 'draft' | 'published' | 'suspended' | 'retired';
  exposureHash: string;
}
```

`agentSkillId` 在 Exposure 生命周期内稳定，不能使用内部 Skill ID。

### 2.10 AgentCardRevision

Runtime 本地保存已应用的不可变 Agent Card 快照并从 A2A Endpoint 读取。

```ts
interface AgentCardRevision {
  revision: number;
  nodeId: string;
  exposureRefs: string[];
  capabilityCatalogHash: string;
  contentHash: string;
  status: 'staged' | 'active' | 'superseded' | 'rejected';
  generatedAt: string;
  activatedAt?: string;
}
```

### 2.11 TaskCapabilityBinding

Runtime 在 Task 正式接受时创建。

```ts
interface TaskCapabilityBinding {
  bindingId: string;
  taskId: string;
  requestedCapabilityId: string;
  capabilityVersion: number;
  exposureId?: string;
  exposureVersion?: number;
  inputSnapshot: unknown;
  successCriteriaSnapshot: CapabilityCriterion[];
  evidenceRequirementSnapshot: CapabilityEvidenceRequirement[];
  constraintSnapshot: CapabilityConstraint[];
  initialImplementationRefs: string[];
  providerPolicySnapshot?: unknown;
  bindingHash: string;
  boundAt: string;
}
```

该记录不可修改。后续调整通过 Attempt/Plan Revision 追加。

### 2.12 TaskExecutionAttempt

```ts
interface TaskExecutionAttempt {
  attemptId: string;
  taskId: string;
  capabilityBindingId: string;
  attemptNo: number;
  planId?: string;
  planTemplateRef?: string;
  skillVersionRefs: string[];
  providerBindingRefs: string[];
  reason:
    | 'initial'
    | 'replan'
    | 'provider_failover'
    | 'recovery'
    | 'manual_change';
  status:
    | 'prepared'
    | 'running'
    | 'waiting'
    | 'succeeded'
    | 'failed'
    | 'canceled'
    | 'superseded';
  startedAt?: string;
  completedAt?: string;
}
```

## 3. A2A 请求能力扩展

组织网络或确定性调用方可选携带：

```json
{
  "metadata": {
    "io.sdar/requestedCapability": {
      "exposureId": "area-inspection",
      "versionConstraint": "1",
      "requestId": "req-123"
    }
  }
}
```

无该字段时，Runtime 通过现有理解与 Skill/Capability 匹配进行解析。解析不唯一时返回标准 `input-required`。
