# 21. 非阻断待办与延期项

以下事项不重新打开 v1.4 基线：

1. 记录 v1.3 最终精确 Commit SHA、Migration Head 和 OpenAPI Inventory Hash；
2. 将逻辑 SQL 映射到仓库最终 Migration 编号；
3. 将 Runtime Control Contract 映射到实际 P12/P13 application ports；
4. 决定首版 Console 是迁移现有 Console 还是同仓新增 Node Console App；
5. 选择 Secret Store 实现；
6. 确定 SMPP Watch 首版采用 SSE、轮询或两者；
7. 确定 Telemetry Query API 的最终 URL 和认证；
8. 确定单节点首版认证采用本地账户、OIDC 或现有网关；
9. P14 Post-Release Operations 可补充 Runbook，不阻塞实现；
10. 组织平台、全局监督、全域交互属于后续产品线。

这些待办只能细化实现，不得改变冻结权威和聚合。
