from pathlib import Path
import json, sys, re
try:
    import yaml
except Exception:
    yaml=None
root=Path(__file__).resolve().parents[1]
errors=[]
for p in (root/'schemas').glob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'{p.name}: {e}')
if yaml:
    for name in ['06-control-plane.openapi.yaml','07-runtime-control-contract.yaml','08-domain-events.yaml','contracts/apply-mode-matrix.yaml','contracts/error-catalog.yaml','contracts/node-api-profile.yaml']:
        try: yaml.safe_load((root/name).read_text(encoding='utf-8'))
        except Exception as e: errors.append(f'{name}: {e}')
sql=(root/'05-data-model.sql').read_text(encoding='utf-8')
for token in ['node_capability_version','task_capability_binding','capability_readiness_snapshot','a2a_exposure_version']:
    if token not in sql: errors.append(f'SQL missing {token}')
for forbidden in ['legacy_capability','compatibility_trigger','dual_write']:
    if forbidden in sql.lower(): errors.append(f'Forbidden compatibility structure: {forbidden}')
print(json.dumps({'ok':not errors,'errors':errors},ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
