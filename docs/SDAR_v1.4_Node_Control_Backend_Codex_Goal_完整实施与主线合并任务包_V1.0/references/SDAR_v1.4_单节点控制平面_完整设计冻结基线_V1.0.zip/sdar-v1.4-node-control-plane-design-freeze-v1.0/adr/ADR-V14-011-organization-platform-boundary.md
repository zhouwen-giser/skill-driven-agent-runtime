# ADR-V14-011-organization-platform-boundary：组织平台边界

- 状态：Accepted / Frozen
- 日期：2026-07-31

## 决策

v1.4 只发布标准 Node API，不实现多节点组织编排。

## 后果

任何改变该决策的实现必须新增 ADR、迁移方案和全链路回归。
