# ADR-V14-007：遥测系统独立

## Decision

SDAR Runtime 和 SMPP 只产生事实；采集、标准化、ClickHouse、ProviderOps 投影和对账统一进入独立 SDAR Telemetry System。

## Consequences

- Console 通过 Telemetry Query Adapter 只读访问；
- Telemetry 不能修改 Task、Capability、Provider 或 Readiness；
- Telemetry 故障不影响在线执行。
