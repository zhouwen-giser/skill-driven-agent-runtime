# ADR-V14-004：A2A 只暴露 Capability Exposure

## Decision

Agent Card `skills[]` 来自 `A2AExposureVersion`，不直接来自内部 Skill。

## Consequences

- 对外业务契约与内部实现解耦；
- `agentSkillId` 稳定；
- 无旧协议兼容要求，直接采用新投影；
- 仍需保持 A2A 标准和 TCK。
