# ADR-V14-006：Node Control Plane 独立部署

## Decision

Control Plane 使用独立进程和数据库。首版可与 Runtime 同机，但故障和发布边界独立。

## Consequences

- Runtime 使用 Bootstrap + LKG，不依赖控制面持续在线；
- Console 由 Control Plane 托管；
- Runtime Management API 保持运行权威；
- 后续组织平台只调用标准 Node API。
