# ADR-V14-010-smpp-mcp-authority：SMPP 与 MCP 权威分离

- 状态：Accepted / Frozen
- 日期：2026-07-31

## 决策

Registry 是候选目录；Discover/Tools 是 Catalog 权威；Availability 是资源执行权威。

## 后果

任何改变该决策的实现必须新增 ADR、迁移方案和全链路回归。
