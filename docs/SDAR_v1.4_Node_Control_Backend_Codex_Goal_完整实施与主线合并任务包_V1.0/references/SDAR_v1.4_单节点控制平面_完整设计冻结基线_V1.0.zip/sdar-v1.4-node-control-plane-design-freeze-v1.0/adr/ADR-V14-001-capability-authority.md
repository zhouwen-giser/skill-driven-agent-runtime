# ADR-V14-001：Node Capability 是唯一业务能力权威

## Decision

新增 `NodeCapabilityDefinitionVersion`。Skill 的能力字符串不再拥有正式能力定义权威；Capability Summary 是派生投影。

## Consequences

- A2A、Task Contract 和组织平台使用稳定 Capability ID；
- Skill 可自由替换而不改变业务契约；
- 需要新增 Capability/Skill/Plan Template 绑定和 Readiness；
- 未发布 Capability 不能对外暴露。
