# ADR-V14-002：复用 P08 Plan Template Artifact

## Decision

Capability 的流程实现仅引用 `plan_template` Artifact 精确版本；不新增 Workflow Template 权威。

## Consequences

- P02/P08 的验证、Promotion、Pointer 和 materialization 继续复用；
- WorkflowDefinition/Instance 保持具体运行对象；
- 若表达不足，扩展 Plan Template Schema，不平行建模。
