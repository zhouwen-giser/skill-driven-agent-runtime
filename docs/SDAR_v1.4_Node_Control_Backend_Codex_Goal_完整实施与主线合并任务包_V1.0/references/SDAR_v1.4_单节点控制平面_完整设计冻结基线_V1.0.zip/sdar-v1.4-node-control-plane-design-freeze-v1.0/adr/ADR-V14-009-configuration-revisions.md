# ADR-V14-009-configuration-revisions：配置统一版本化

- 状态：Accepted / Frozen
- 日期：2026-07-31

## 决策

所有控制对象采用 Draft/Validate/Publish/Apply/Ack/LKG；运行中任务使用快照。

## 后果

任何改变该决策的实现必须新增 ADR、迁移方案和全链路回归。
