# ADR-V14-008：v1.4 使用全新数据库基线

## Decision

产品尚未正式发布，不提供旧实验数据库兼容、双写、Alias 或在线升级迁移。

## Consequences

- 可以删除旧 Capability/Agent Card 实验结构；
- 直接建立准确 FK、状态和唯一约束；
- 开发/测试数据库重建；
- 保持业务行为、协议和验收语义回归。
