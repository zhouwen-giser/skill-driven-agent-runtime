# ADR-V14-005：Capability Readiness 属于 Runtime

## Decision

Readiness 由 Runtime 基于已应用定义、Skill、Plan Template、Provider Availability、Model Route 和 Policy 确定性计算。

## Consequences

- Control Plane 只能请求评估和读取；
- A2A Task 接受使用 Runtime Readiness；
- Readiness 以事件驱动快照、TTL 和迟滞维护。
