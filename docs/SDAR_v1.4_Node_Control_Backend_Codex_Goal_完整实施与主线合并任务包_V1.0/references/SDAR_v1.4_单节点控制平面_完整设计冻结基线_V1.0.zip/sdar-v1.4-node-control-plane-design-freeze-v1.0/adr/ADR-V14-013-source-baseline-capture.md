# ADR-V14-013-source-baseline-capture：来源 SHA 捕获

- 状态：Accepted / Frozen
- 日期：2026-07-31

## 决策

设计可以冻结；首个实施 PR 前必须记录 v1.3 精确 SHA 和 Migration Head。

## 后果

任何改变该决策的实现必须新增 ADR、迁移方案和全链路回归。
