# ADR-V14-003：Task 接受时创建不可变能力绑定

## Decision

Task 正式 accepted 时，与 `TaskCapabilityBinding` 在同一 Runtime PostgreSQL 事务提交。

## Consequences

- 任务承诺可审计；
- 后续 Replan/Skill/Provider 变化以 Attempt 追加；
- Terminal Judge 使用冻结的成功条件和证据要求。
