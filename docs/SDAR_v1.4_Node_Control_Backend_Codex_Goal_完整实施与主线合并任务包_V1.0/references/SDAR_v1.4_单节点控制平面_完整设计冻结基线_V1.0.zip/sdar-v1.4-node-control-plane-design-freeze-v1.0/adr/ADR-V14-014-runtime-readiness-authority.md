# ADR-V14-014-runtime-readiness-authority：Readiness 权威

- 状态：Accepted / Frozen
- 日期：2026-07-31

## 决策

Readiness 由 Runtime 确定性计算，控制面只请求和读取。

## 后果

任何改变该决策的实现必须新增 ADR、迁移方案和全链路回归。
