# 19. 验证与发布门禁冻结基线

## 1. 基线验收场景

### AC-V14-001 独立控制面

停止 Node Control Plane 后：

- Runtime 继续接受符合当前 Active/LKG 的任务；
- 已运行任务继续；
- A2A Agent Card 继续读取本地 Active Revision；
- Provider/Remote Task 继续；
- 仅新的配置发布和控制台写操作不可用。

### AC-V14-002 Capability 唯一权威

- 无正式 Capability Definition 时不能发布 A2A Exposure；
- Skill 标签不能直接进入 Agent Card；
- Summary 只能由正式定义与实现快照派生。

### AC-V14-003 Task 原子绑定

Task accepted、`TaskCapabilityBinding` 和首个 Task Transition 必须同事务；任一失败不得留下半绑定 Task。

### AC-V14-004 版本稳定

发布 Capability/Skill/Plan Template 新版本后，既有 Task 仍使用原始快照；新 Task 使用新 Active 版本。

### AC-V14-005 A2A

- Agent Card 只暴露 Exposure；
- 内部 Skill/Provider/Workflow 信息不泄漏；
- Requested Capability 明确时确定性绑定；
- 歧义时 input-required；
- TCK 不回退。

### AC-V14-006 Readiness

- Provider Catalog、Availability、Model Route 或 Policy 变化触发重算；
- 短时抖动受 TTL/迟滞控制；
- Readiness 不能由控制台直接写入。

### AC-V14-007 SMPP

- Registry 可用、Telemetry 停止时仍可导入/调用；
- Telemetry 可用、Registry 停止时不能自动导入；
- 同 ID 不同 Source 不错误合并；
- LKG 过期按策略 fail closed。

### AC-V14-008 Telemetry 隔离

Telemetry/ClickHouse 不可用不影响 Task、Workflow、Provider、Agent Card 和 Readiness 在线权威。

### AC-V14-009 配置发布

- Publish 不等于 Applied；
- Runtime Reject 不改变 Active/LKG；
- restart_required 不被伪装为 applied；
- Rollback 通过发布新 Revision 完成。

### AC-V14-010 安全

- 所有 Control Plane 写接口认证；
- Secret 不出现在 API、日志、Audit、Telemetry；
- 重放 Idempotency Key 返回原结果；
- 不同请求复用同 Key fail closed。

## 2. 追踪矩阵模板

| Requirement | Domain | API | Storage | Test | Evidence |
|---|---|---|---|---|---|
| V14-CAP-001 | NodeCapability | `/node-capabilities` | `node_capability_version` | unit+integration | report |
| V14-A2A-001 | A2AExposure | `/a2a-exposures` | `a2a_exposure_version` | contract+TCK | report |
| V14-TASK-001 | TaskCapabilityBinding | task accept | Runtime table | integration+e2e | report |
| V14-CFG-001 | ConfigurationRevision | `/configuration-revisions` | control tables | integration | report |
| V14-SMPP-001 | SmppRegistrySource | `/smpp-sources` | source/snapshot | contract+e2e | report |
| V14-TEL-001 | TelemetryLink | `/telemetry-links` | link only | outage e2e | report |

## 3. Fresh Baseline 数据库门禁

- 空库完整创建；
- 重复应用幂等；
- 全部 CHECK/UNIQUE/FK 生效；
- 不运行旧实验数据迁移；
- Seed 仅包含 Mock/Local 配置；
- Production reset 禁止；
- 开发 reset 需环境、库名和显式确认；
- Runtime 和 Control Plane 数据库分别验证。
