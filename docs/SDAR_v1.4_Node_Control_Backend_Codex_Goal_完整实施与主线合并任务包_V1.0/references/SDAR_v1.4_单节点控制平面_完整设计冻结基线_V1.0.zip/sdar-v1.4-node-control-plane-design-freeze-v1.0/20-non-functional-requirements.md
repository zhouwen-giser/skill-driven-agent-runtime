# 20. 非功能需求基线

## 1. 性能

- Console 常规只读 P95 < 500ms（不含外部 Telemetry 深度查询）；
- Control Plane 常规写入受理 P95 < 800ms；长时操作返回 Operation ID；
- Agent Card 本地读取 P95 < 100ms；
- Capability Readiness 读取不得实时串行探测所有 Provider；
- 单节点首版支持至少 100 个 Capability、1000 个 Skill Version、100 个 Provider Binding。

## 2. 可靠性

- Control Plane outage 不影响 Runtime；
- Publish/Apply/Ack 幂等；
- Runtime 使用 LKG 冷启动；
- Registry/Telemetry 外部依赖均有超时、熔断和有界缓存；
- 所有持久化状态可从 PostgreSQL 恢复。

## 3. 一致性

- Published 定义不可变；
- Active Pointer 使用 CAS；
- Task Acceptance 与 TaskCapabilityBinding 同事务；
- Agent Card 内容 Hash 与 Capability Catalog Hash 可对账；
- Provider 来源 ID 不跨 SMPP 错误合并。

## 4. 可观测性

每个管理操作和运行适配调用具有 Trace、Reason Code、Latency 和结果；但遥测不可成为运行权威。

## 5. 可维护性

- Domain 不依赖 Web/DB/Runtime SDK；
- Adapter 映射仓库源码符号；
- OpenAPI/Schema/Event Contract 机器校验；
- 架构依赖和禁止依赖由 `verify:architecture` 检查。

## 6. 可移植性

Node 22/pnpm 11 为目标工具链；数据库 PostgreSQL；部署首版不强制 Kubernetes。
