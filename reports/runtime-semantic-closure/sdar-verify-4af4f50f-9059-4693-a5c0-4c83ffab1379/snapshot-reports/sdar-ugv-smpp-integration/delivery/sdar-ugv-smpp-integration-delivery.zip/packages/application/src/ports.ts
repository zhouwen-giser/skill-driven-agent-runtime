import type {
  AgentTask,
  ConversationContext,
  Goal,
  GoalExecutionContract,
  McpServer,
  McpDependencyWarning,
  McpInvocation,
  McpManagementOperation,
  McpTool,
  McpToolEnhancement,
  McpProtocolDiscoverySnapshot,
  McpToolExecutionSemantics,
  RemoteTaskOperationAck,
  RemoteTaskBinding,
  RemoteTaskControlEvent,
  RemoteTaskObservation,
  RemoteTaskProtocolAttempt,
  RemoteTaskInputLink,
  RemoteTaskCancellationRequest,
  RemoteTaskCancellationAttempt,
  RemoteTaskCancellationProviderTerminalStatus,
  RemoteTaskSnapshot,
  ModelInvocationRecord,
  ModelProviderConfiguration,
  ModelStage,
  StageModelRoute,
  PromptEffectSummary,
  PromptVersion,
  McpToolDependencyChange,
  MemoryItem,
  MemorySearchHit,
  MemoryStatusTransition,
  MemoryRetentionPolicy,
  Skill,
  SkillRelation,
  SkillRelationType,
  SkillPerformanceMetrics,
  SkillReplacementPlan,
  SkillSelectionRecord,
  SkillExecutionEvent,
  SkillExecutionRecord,
  SkillExecutionReference,
  SkillExecutionView,
  SkillInputResolutionRecord,
  SkillQualityObservation,
  SkillQualityWarning,
  SkillQualityWarningKind,
  SkillDraft,
  SkillCallWorkflowRecord,
  SkillVersion,
  SkillPackageImportAudit,
  SkillFormalizationCandidate,
  SkillEvolutionCorrectionExperience,
  EvolutionExperience,
  EvolutionPolicy,
  EvolutionTriggerRecord,
  TemporarySkill,
  TemporarySkillExperience,
  ToolReference,
  WorkflowPlanAttempt,
  WorkflowPlanRecord,
  WorkflowDefinition,
  WorkflowBudgetLimits,
  WorkflowBudgetTerminationReason,
  WorkflowBudgetUsage,
  WorkflowInstance,
  WorkflowTemplate,
  WorkflowTemplateOccurrence,
  WorkflowTemplateUse,
  WorkflowNodeEvent,
  WorkflowControlRecord,
  WorkflowControlRound,
  GoalEvaluationResult,
  GoalPatchRecord,
  GoalInferenceSource,
  GoalInputInferenceRecord,
  ImplicitFeedbackRecord,
  EvaluationInfluenceRecord,
  EvaluationAnalyticsFilter,
  EvaluationAnalyticsSample,
  GoalTransitionRecord,
  GoalCancellationRecord,
  ProcessedResultRecord,
  TaskWaitPolicy,
  TaskQualityReport,
  TaskInputRequest,
  TaskInputResponse,
  RuntimeExecutionContext,
  RuntimeAchievedOutcomeInput,
  RuntimeCanceledOutcomeInput,
  RuntimeEnhancementWarning,
  RuntimeTerminalOutcomeRecord,
  RuntimeUnachievableOutcomeInput,
  TaskExecutionAttempt,
  McpTaskOperationDefinition,
  McpTaskOperationCandidate,
  TaskAvailabilityCheckRequest,
  TaskAvailabilityReadResult,
  TaskAvailabilitySnapshot,
  DslExecutionReadiness,
  WorkflowContinuationSnapshot,
  WorkflowContinuationAttempt,
  WorkflowContinuationLifecycle,
  WorkflowContinuationAttemptStatus,
  WorkflowExternalWaitResolution,
  WorkflowRuntimeContinuationState,
  WorkflowConfirmationResume,
  SkillTaskReadinessSummary,
  SkillTaskBinding,
} from '../../domain/src/index.js';

export interface ConversationContextRepository {
  findById(contextId: string): Promise<ConversationContext | undefined>;
  save(context: ConversationContext): Promise<void>;
}

export interface GoalRepository {
  findById(goalId: string): Promise<Goal | undefined>;
  findActiveByContextId(contextId: string): Promise<Goal | undefined>;
  findLatestByContextId(contextId: string): Promise<Goal | undefined>;
  listByContextId(contextId: string): Promise<readonly Goal[]>;
  listTransitions(contextId: string): Promise<readonly GoalTransitionRecord[]>;
  save(goal: Goal, transition?: GoalTransitionRecord): Promise<void>;
}

export interface GoalPatchRepository {
  apply(
    record: Omit<GoalPatchRecord, 'invalidatedPlanIds' | 'invalidatedInstanceIds'>,
    triggeringTaskId?: string,
  ): Promise<GoalPatchRecord>;
  find(patchId: string): Promise<GoalPatchRecord | undefined>;
  listByGoal(goalId: string): Promise<readonly GoalPatchRecord[]>;
}

export interface GoalCancellationRepository {
  cancel(
    input: Omit<
      GoalCancellationRecord,
      'canceledTaskIds' | 'invalidatedPlanIds' | 'canceledInstanceIds'
    >,
  ): Promise<GoalCancellationRecord>;
  find(cancellationId: string): Promise<GoalCancellationRecord | undefined>;
  listByGoal(goalId: string): Promise<readonly GoalCancellationRecord[]>;
}

export interface ProcessedResultRepository {
  save(record: ProcessedResultRecord): Promise<void>;
  find(resultId: string): Promise<ProcessedResultRecord | undefined>;
  listByTask(taskId: string): Promise<readonly ProcessedResultRecord[]>;
}

export interface TaskQualityReportRepository {
  save(report: TaskQualityReport): Promise<void>;
  findByTask(taskId: string): Promise<TaskQualityReport | undefined>;
}

export interface EvaluationInfluenceRepository {
  save(record: EvaluationInfluenceRecord): Promise<void>;
  findByReport(reportId: string): Promise<EvaluationInfluenceRecord | undefined>;
}

export interface EvaluationAnalyticsRepository {
  query(filters: EvaluationAnalyticsFilter): Promise<readonly EvaluationAnalyticsSample[]>;
}

export interface ImplicitFeedbackRepository {
  findPreviousTerminal(contextId: string, excludeTaskId: string): Promise<AgentTask | undefined>;
  save(record: ImplicitFeedbackRecord): Promise<void>;
  listByTask(taskId: string): Promise<readonly ImplicitFeedbackRecord[]>;
}

export interface MemoryRepository {
  save(
    item: MemoryItem,
    embedding: Readonly<{ providerId: string; vector: readonly number[] }>,
  ): Promise<void>;
  find(memoryId: string): Promise<MemoryItem | undefined>;
  search(
    query: Readonly<{
      providerId: string;
      vector: readonly number[];
      limit: number;
      userId?: string;
    }>,
  ): Promise<readonly MemorySearchHit[]>;
  saveAndSupersede(
    replacement: MemoryItem,
    embedding: Readonly<{ providerId: string; vector: readonly number[] }>,
    transitions: readonly MemoryStatusTransition[],
  ): Promise<void>;
  invalidate(transition: MemoryStatusTransition): Promise<void>;
  listTransitions(memoryId: string): Promise<readonly MemoryStatusTransition[]>;
}

export interface MemoryRetentionPolicyRepository {
  get(): Promise<MemoryRetentionPolicy>;
  update(policy: MemoryRetentionPolicy): Promise<void>;
}

export interface GoalInputInferenceRepository {
  collect(
    contextId: string,
    excludeTaskId: string,
    limit: number,
  ): Promise<
    Readonly<{
      conversationHistory: readonly GoalInferenceSource[];
      existingData: readonly GoalInferenceSource[];
    }>
  >;
  save(record: GoalInputInferenceRecord): Promise<void>;
  listByTask(taskId: string): Promise<readonly GoalInputInferenceRecord[]>;
}

export interface RuntimeRecoveryRepository {
  failInterrupted(
    timestamp: string,
  ): Promise<Readonly<{ tasks: number; workflowInstances: number; taskAttempts: number }>>;
}

export interface WorkflowControlRepository {
  find(controlId: string): Promise<WorkflowControlRecord | undefined>;
  save(control: WorkflowControlRecord): Promise<void>;
  saveRound(round: WorkflowControlRound): Promise<void>;
  listRounds(controlId: string): Promise<readonly WorkflowControlRound[]>;
}

export interface RuntimeTerminalOutcomeRepository {
  commitAchieved(input: RuntimeAchievedOutcomeInput): Promise<RuntimeTerminalOutcomeRecord>;
  commitUnachievable(input: RuntimeUnachievableOutcomeInput): Promise<RuntimeTerminalOutcomeRecord>;
  commitCanceled(input: RuntimeCanceledOutcomeInput): Promise<RuntimeTerminalOutcomeRecord>;
  recordEnhancementWarning(outcomeId: string, warning: RuntimeEnhancementWarning): Promise<void>;
  find(outcomeId: string): Promise<RuntimeTerminalOutcomeRecord | undefined>;
  findByControl(controlId: string): Promise<RuntimeTerminalOutcomeRecord | undefined>;
}

export interface GoalEvaluator {
  evaluate(
    input: Readonly<{ goal: Goal; instance: WorkflowInstance; taskId?: string }>,
  ): Promise<GoalEvaluationResult>;
}

export interface AgentTaskRepository {
  findById(taskId: string): Promise<AgentTask | undefined>;
  findByPlanId(planId: string): Promise<AgentTask | undefined>;
  list(
    query: Readonly<{
      contextId?: string;
      goalId?: string;
      planId?: string;
      skillId?: string;
      phase?: AgentTask['phase'];
      limit: number;
    }>,
  ): Promise<readonly AgentTask[]>;
  save(task: AgentTask): Promise<void>;
}

export interface TaskInputRepository {
  createRequest(request: TaskInputRequest): Promise<void>;
  findRequest(inputRequestId: string): Promise<TaskInputRequest | undefined>;
  findPendingByTask(taskId: string): Promise<TaskInputRequest | undefined>;
  cancelPending(
    taskId: string,
    status: Extract<TaskInputRequest['status'], 'expired' | 'canceled'>,
  ): Promise<void>;
  listResponses(taskId: string): Promise<readonly TaskInputResponse[]>;
  createInitialAttempt(attempt: TaskExecutionAttempt): Promise<void>;
  answerAndCreateAttempt(
    input: Readonly<{
      inputRequestId: string;
      taskId: string;
      response: TaskInputResponse;
      attempt: TaskExecutionAttempt;
      answeredAt: string;
      continuationPhase: Extract<
        AgentTask['phase'],
        'goal_deliberation' | 'planning' | 'executing'
      >;
      phaseMessage: string;
    }>,
  ): Promise<AgentTask>;
  listQueuedAttempts(limit: number): Promise<readonly TaskExecutionAttempt[]>;
  findAttempt(attemptId: string): Promise<TaskExecutionAttempt | undefined>;
  findResponseForAttempt(
    attemptId: string,
  ): Promise<Readonly<{ request: TaskInputRequest; response: TaskInputResponse }> | undefined>;
  updateAttempt(
    attemptId: string,
    status: Exclude<TaskExecutionAttempt['status'], 'queued'>,
    timestamp: string,
    errorCode?: string,
  ): Promise<void>;
}

export interface TaskWaitPolicyRepository {
  get(): Promise<TaskWaitPolicy>;
  update(policy: TaskWaitPolicy): Promise<void>;
  expireWaiting(cutoff: string, timestamp: string): Promise<readonly AgentTask[]>;
}

export interface SkillDraftRepository {
  findById(draftId: string): Promise<SkillDraft | undefined>;
  listByContextId(contextId: string): Promise<readonly SkillDraft[]>;
  save(draft: SkillDraft): Promise<void>;
  markPublished(
    draftId: string,
    publication: Readonly<{
      skillId: string;
      version: number;
      publishedBy: string;
      publishedAt: string;
    }>,
  ): Promise<SkillDraft>;
}

export interface SkillRepository {
  find(skillId: string): Promise<Skill | undefined>;
  findCurrentVersion(skillId: string): Promise<SkillVersion | undefined>;
  findVersion(skillId: string, version: number): Promise<SkillVersion | undefined>;
  listVersions(skillId: string): Promise<readonly SkillVersion[]>;
  listEnabledVersions(): Promise<readonly SkillVersion[]>;
  listCurrentVersions(): Promise<readonly SkillVersion[]>;
  saveVersionAndSetCurrent(
    version: SkillVersion,
    timestamp: string,
    packageImport?: SkillPackageImportAudit,
  ): Promise<void>;
}

export interface SkillGraphRepository {
  listRelations(): Promise<readonly SkillRelation[]>;
  listRelationsFrom(
    sourceSkillId: string,
    relationTypes: readonly SkillRelationType[],
    limit: number,
  ): Promise<readonly SkillRelation[]>;
  saveRelation(relation: SkillRelation): Promise<void>;
  deleteRelation(relationId: string): Promise<void>;
}

export interface SkillSelectionRepository {
  findMetrics(skillId: string): Promise<SkillPerformanceMetrics | undefined>;
  saveMetrics(skillId: string, metrics: SkillPerformanceMetrics, updatedAt: string): Promise<void>;
  saveSelection(record: SkillSelectionRecord): Promise<void>;
  findSelection(selectionId: string): Promise<SkillSelectionRecord | undefined>;
  saveReplacementPlan(plan: SkillReplacementPlan): Promise<void>;
}

export interface SkillExecutionRepository {
  create(
    record: SkillExecutionRecord,
    events: readonly SkillExecutionEvent[],
    references: readonly SkillExecutionReference[],
  ): Promise<SkillExecutionView>;
  appendEvent(event: SkillExecutionEvent): Promise<SkillExecutionView>;
  appendReference(reference: SkillExecutionReference): Promise<SkillExecutionView>;
  find(executionId: string): Promise<SkillExecutionView | undefined>;
  findByPlan(workflowPlanId: string): Promise<SkillExecutionView | undefined>;
  listByTask(taskId: string): Promise<readonly SkillExecutionView[]>;
  listChildren(parentExecutionId: string): Promise<readonly SkillExecutionView[]>;
}

export interface SkillInputResolutionRepository {
  save(record: SkillInputResolutionRecord): Promise<void>;
  find(resolutionId: string): Promise<SkillInputResolutionRecord | undefined>;
  findLatest(
    taskId: string,
    skillId: string,
    skillVersion: number,
    goalVersion: number,
  ): Promise<SkillInputResolutionRecord | undefined>;
  listByTask(taskId: string): Promise<readonly SkillInputResolutionRecord[]>;
  listProcessedDataByContext(
    contextId: string,
    excludeTaskId: string,
    limit: number,
  ): Promise<readonly Readonly<{ sourceRef: string; value: unknown }>[]>;
}

export interface SkillQualityRepository {
  saveObservation(observation: SkillQualityObservation): Promise<void>;
  listRecentObservations(
    skillId: string,
    skillVersion: number,
    limit: number,
  ): Promise<readonly SkillQualityObservation[]>;
  findActiveWarning(
    skillId: string,
    skillVersion: number,
    kind: SkillQualityWarningKind,
  ): Promise<SkillQualityWarning | undefined>;
  saveWarning(warning: SkillQualityWarning): Promise<void>;
  listWarnings(skillId?: string): Promise<readonly SkillQualityWarning[]>;
}

export interface SkillSemanticRetriever {
  score(
    goalContract: GoalExecutionContract,
    skills: readonly SkillVersion[],
  ): Promise<Readonly<Record<string, number>>>;
}

export interface TextEmbeddingProvider {
  embed(text: string): Promise<Readonly<{ providerId: string; vector: readonly number[] }>>;
}

export interface SkillEmbeddingRepository {
  upsert(
    input: Readonly<{
      skillId: string;
      skillVersion: number;
      providerId: string;
      searchableText: string;
      vector: readonly number[];
      updatedAt: string;
    }>,
  ): Promise<void>;
  cosineScores(
    input: Readonly<{
      skillIds: readonly string[];
      providerId: string;
      vector: readonly number[];
    }>,
  ): Promise<Readonly<Record<string, number>>>;
}

export interface SkillSelectionDecider {
  decide(
    input: Readonly<{
      goalContract: GoalExecutionContract;
      candidates: SkillSelectionRecord['candidates'];
      mode: 'initial' | 'replacement';
      failedSkillId?: string;
    }>,
  ): Promise<Readonly<{ selectedSkillId: string; decisionSummary: string }>>;
}

export interface TemporarySkillRepository {
  find(temporarySkillId: string): Promise<TemporarySkill | undefined>;
  listByTask(taskId: string): Promise<readonly TemporarySkill[]>;
  save(skill: TemporarySkill): Promise<void>;
  expireAndSaveExperience(
    skill: TemporarySkill,
    experience: TemporarySkillExperience,
  ): Promise<void>;
  listSuccessfulExperiences(
    capabilityFingerprint: string,
  ): Promise<readonly TemporarySkillExperience[]>;
  findFormalizationCandidate(
    capabilityFingerprint: string,
  ): Promise<SkillFormalizationCandidate | undefined>;
  findFormalizationCandidateById(
    candidateId: string,
  ): Promise<SkillFormalizationCandidate | undefined>;
  saveFormalizationCandidate(candidate: SkillFormalizationCandidate): Promise<void>;
  saveCorrectionExperience(correction: SkillEvolutionCorrectionExperience): Promise<void>;
  listCorrectionExperiences(
    candidateId: string,
  ): Promise<readonly SkillEvolutionCorrectionExperience[]>;
}

export interface EvolutionExperienceRepository {
  save(experience: EvolutionExperience): Promise<void>;
  find(experienceId: string): Promise<EvolutionExperience | undefined>;
  findByInstance(instanceId: string): Promise<EvolutionExperience | undefined>;
  listByGoal(goalId: string): Promise<readonly EvolutionExperience[]>;
  listBySkill(skillId: string): Promise<readonly EvolutionExperience[]>;
  listByTool(reference: ToolReference): Promise<readonly EvolutionExperience[]>;
}

export interface WorkflowTemplateRepository {
  saveOccurrence(occurrence: WorkflowTemplateOccurrence): Promise<void>;
  listOccurrences(
    goalKey: string,
    structureKey: string,
  ): Promise<readonly WorkflowTemplateOccurrence[]>;
  findPreferred(goalKey: string): Promise<WorkflowTemplate | undefined>;
  saveTemplate(template: WorkflowTemplate): Promise<void>;
  saveUse(use: WorkflowTemplateUse): Promise<void>;
  findPlannedUse(
    workflowDefinitionId: string,
    workflowVersion: number,
  ): Promise<WorkflowTemplateUse | undefined>;
  completeUse(use: WorkflowTemplateUse, template: WorkflowTemplate): Promise<void>;
  listTemplates(): Promise<readonly WorkflowTemplate[]>;
  listUses(templateId: string): Promise<readonly WorkflowTemplateUse[]>;
}

export interface EvolutionPolicyRepository {
  get(): Promise<EvolutionPolicy>;
  update(policy: EvolutionPolicy): Promise<void>;
  saveTrigger(trigger: EvolutionTriggerRecord): Promise<void>;
  listTriggers(capabilityFingerprint?: string): Promise<readonly EvolutionTriggerRecord[]>;
}

export interface McpToolCatalog {
  exists(reference: ToolReference): Promise<boolean>;
  getInputSchema(reference: ToolReference): Promise<unknown>;
}

export interface McpTaskOperationCatalog {
  getTaskOperationDefinition(
    reference: ToolReference,
  ): Promise<McpTaskOperationDefinition | undefined>;
}

export interface SkillTaskOperationCandidateCatalog {
  listTaskOperationCandidates(taskType: string): Promise<readonly McpTaskOperationCandidate[]>;
}

export interface TaskAvailabilityBatchReader {
  checkTaskAvailability(
    input: Readonly<{
      serverId: string;
      requests: readonly TaskAvailabilityCheckRequest[];
      executionContext: RuntimeExecutionContext;
      signal?: AbortSignal;
    }>,
  ): Promise<TaskAvailabilityReadResult>;
}

/** Phase 4 read-only abstraction; Phase 8 maps the v1.1 authority without copying its state model. */
export interface SkillTaskReadinessPort {
  inspect(
    input: Readonly<{
      skillId: string;
      skillVersion: number;
      taskBindings: readonly SkillTaskBinding[];
      allowPreferredProviderFallback: boolean;
    }>,
  ): Promise<SkillTaskReadinessSummary>;
}

export interface TaskAvailabilityEvidenceRepository {
  saveEvaluation(
    readiness: DslExecutionReadiness,
    snapshots: readonly TaskAvailabilitySnapshot[],
  ): Promise<void>;
  listByPlan(
    planId: string,
    filter?: Readonly<{
      phase?: DslExecutionReadiness['checkPhase'] | undefined;
      limit?: number | undefined;
    }>,
  ): Promise<
    readonly Readonly<{
      readiness: DslExecutionReadiness;
      snapshots: readonly TaskAvailabilitySnapshot[];
    }>[]
  >;
  findLatestPlanning(planId: string): Promise<
    | Readonly<{
        readiness: DslExecutionReadiness;
        snapshots: readonly TaskAvailabilitySnapshot[];
      }>
    | undefined
  >;
}

export interface McpServerRecord {
  readonly server: McpServer;
  readonly encryptedCredential: string;
}

export interface CurrentMcpProviderBindingAuthorityPort {
  loadCurrentMcpProviderBinding(
    input: Readonly<{ bindingId?: string; localServerId: string }>,
  ): Promise<
    Readonly<{
      observedAt: string;
      binding: Readonly<{
        bindingId: string;
        revision: number;
        localServerId: string;
        providerId: string;
        endpointRef: string;
        catalogRevision: string;
        catalogChecksum: string;
        operationCount: number;
        availabilityValidUntil: string;
      }>;
    }>
  >;
}

export interface McpRegistryRepository {
  findServer(serverId: string): Promise<McpServerRecord | undefined>;
  listServers(): Promise<readonly McpServer[]>;
  listTools(serverId: string): Promise<readonly McpTool[]>;
  findCurrentProtocolSnapshot?(serverId: string): Promise<McpProtocolDiscoverySnapshot | undefined>;
  saveServerAndReplaceTools(
    record: McpServerRecord,
    tools: readonly McpTool[],
    changes?: readonly McpToolDependencyChange[],
  ): Promise<void>;
  deleteServer(serverId: string): Promise<void>;
  saveInvocation(invocation: McpInvocation): Promise<void>;
  listInvocations(serverId: string): Promise<readonly McpInvocation[]>;
  listInvocationsByTask(taskId: string): Promise<readonly McpInvocation[]>;
  saveManagementOperation(operation: McpManagementOperation): Promise<void>;
  listManagementOperations(serverId: string): Promise<readonly McpManagementOperation[]>;
  listDependencyWarnings(serverId: string): Promise<readonly McpDependencyWarning[]>;
  updateToolEnhancement(
    serverId: string,
    toolName: string,
    enhancement: McpToolEnhancement,
  ): Promise<void>;
  updateToolExecutionSemantics(
    serverId: string,
    toolName: string,
    adminOverride: McpToolExecutionSemantics,
    effective: McpToolExecutionSemantics,
    operation: McpManagementOperation,
  ): Promise<boolean>;
}

export interface SecretCipher {
  encrypt(secret: Readonly<Record<string, string>>): string;
  decrypt(encrypted: string): Readonly<Record<string, string>>;
}

export type RemoteTaskReadResult =
  | Readonly<{ kind: 'snapshot'; snapshot: RemoteTaskSnapshot }>
  | Readonly<{ kind: 'provider_unreachable'; errorCode: string }>
  | Readonly<{ kind: 'contract_invalid'; errorCode: string }>
  | Readonly<{ kind: 'provider_protocol'; errorCode: string }>;

export interface RemoteTaskSnapshotReader {
  readRemoteTask(
    input: Readonly<{
      serverId: string;
      operationName: string;
      remoteTaskId: string;
      executionContext: RuntimeExecutionContext;
    }>,
  ): Promise<RemoteTaskReadResult>;
}

export type RemoteTaskMutationResult =
  | Readonly<{ applied: false; reason: 'missing' | 'stale' | 'closed' }>
  | Readonly<{
      applied: true;
      binding: RemoteTaskBinding;
      snapshotAccepted?: boolean;
      controlEvent?: RemoteTaskControlEvent;
    }>;

export type RemoteTaskPollClaimResult =
  | Readonly<{ claimed: false; reason: 'missing' | 'stale' | 'closed' | 'leased' }>
  | Readonly<{ claimed: true; binding: RemoteTaskBinding }>;

export interface RemoteTaskRepository {
  admit(
    binding: RemoteTaskBinding,
    acceptedObservationId: string,
  ): Promise<Readonly<{ binding: RemoteTaskBinding; created: boolean }>>;
  findById(bindingId: string): Promise<RemoteTaskBinding | undefined>;
  findByRemoteIdentity(
    serverId: string,
    remoteTaskId: string,
  ): Promise<RemoteTaskBinding | undefined>;
  listRequiringPoll(
    now: string,
    limit: number,
    afterBindingId?: string,
  ): Promise<readonly RemoteTaskBinding[]>;
  listActiveByServer(serverId: string, limit: number): Promise<readonly RemoteTaskBinding[]>;
  claimPoll(
    input: Readonly<{
      bindingId: string;
      expectedVersion: number;
      claimToken: string;
      claimedAt: string;
      expiresAt: string;
    }>,
  ): Promise<RemoteTaskPollClaimResult>;
  recordSnapshot(
    input: Readonly<{
      bindingId: string;
      expectedVersion: number;
      claimToken: string;
      snapshot: RemoteTaskSnapshot;
      observationId: string;
      controlEventId?: string;
      resultHash?: string;
      observedAt: string;
      nextPollAt?: string;
      protocolAttempt: RemoteTaskProtocolAttempt;
    }>,
  ): Promise<RemoteTaskMutationResult>;
  recordExternalSnapshot(
    input: Readonly<{
      bindingId: string;
      expectedVersion: number;
      snapshot: RemoteTaskSnapshot;
      observationId: string;
      source: 'notification' | 'reconciliation';
      subscriptionId?: string;
      controlEventId?: string;
      resultHash?: string;
      observedAt: string;
    }>,
  ): Promise<RemoteTaskMutationResult>;
  recordProviderFailure(
    input: Readonly<{
      bindingId: string;
      expectedVersion: number;
      claimToken: string;
      observationId: string;
      errorCode: string;
      observedAt: string;
      nextPollAt: string;
      protocolAttempt: RemoteTaskProtocolAttempt;
    }>,
  ): Promise<RemoteTaskMutationResult>;
  quarantine(
    input: Readonly<{
      bindingId: string;
      expectedVersion: number;
      claimToken: string;
      observationId: string;
      errorCode: string;
      observedAt: string;
      protocolAttempt: RemoteTaskProtocolAttempt;
    }>,
  ): Promise<RemoteTaskMutationResult>;
  listObservations(bindingId: string): Promise<readonly RemoteTaskObservation[]>;
  listControlEvents(bindingId: string): Promise<readonly RemoteTaskControlEvent[]>;
  listProtocolAttempts(bindingId: string): Promise<readonly RemoteTaskProtocolAttempt[]>;
}

export type RemoteTaskCancellationRequestResult =
  | Readonly<{ requested: false; reason: 'missing' | 'stale' | 'terminal' | 'closed' }>
  | Readonly<{ requested: true; request: RemoteTaskCancellationRequest; created: boolean }>;

export type RemoteTaskCancellationClaimResult =
  | Readonly<{ claimed: false; reason: 'missing' | 'stale' | 'resolved' | 'leased' }>
  | Readonly<{ claimed: true; request: RemoteTaskCancellationRequest }>;

export type RemoteTaskCancellationMutationResult =
  | Readonly<{ applied: false; reason: 'missing' | 'stale' | 'resolved' }>
  | Readonly<{ applied: true; request: RemoteTaskCancellationRequest }>;

export interface RemoteTaskCancellationRepository {
  requestCancellation(
    request: RemoteTaskCancellationRequest,
    expectedBindingVersion: number,
  ): Promise<RemoteTaskCancellationRequestResult>;
  findCancellation(requestId: string): Promise<RemoteTaskCancellationRequest | undefined>;
  listRequiringDelivery(
    now: string,
    limit: number,
  ): Promise<readonly RemoteTaskCancellationRequest[]>;
  claimCancellation(
    input: Readonly<{
      requestId: string;
      expectedVersion: number;
      claimToken: string;
      claimedAt: string;
      expiresAt: string;
    }>,
  ): Promise<RemoteTaskCancellationClaimResult>;
  recordCancellationAcknowledged(
    input: Readonly<{
      requestId: string;
      expectedVersion: number;
      claimToken: string;
      attempt: RemoteTaskCancellationAttempt;
      acknowledgedAt: string;
      protocolRevision: string;
    }>,
  ): Promise<RemoteTaskCancellationMutationResult>;
  recordCancellationUncertain(
    input: Readonly<{
      requestId: string;
      expectedVersion: number;
      claimToken: string;
      attempt: RemoteTaskCancellationAttempt;
      errorCode: string;
      observedAt: string;
    }>,
  ): Promise<RemoteTaskCancellationMutationResult>;
  resolveCancellationFromProvider(
    bindingId: string,
    status: RemoteTaskCancellationProviderTerminalStatus,
    resolvedAt: string,
  ): Promise<readonly RemoteTaskCancellationRequest[]>;
  listCancellationAttempts(requestId: string): Promise<readonly RemoteTaskCancellationAttempt[]>;
}

export interface RemoteTaskCancellationSender {
  cancelRemoteTask(
    input: Readonly<{
      serverId: string;
      remoteTaskId: string;
      executionContext: RuntimeExecutionContext;
    }>,
  ): Promise<RemoteTaskOperationAck>;
}

export type RemoteTaskInputAttemptStatus =
  'acknowledged' | 'provider_unreachable' | 'contract_invalid' | 'provider_protocol';

export interface RemoteTaskInputAttempt {
  readonly attemptId: string;
  readonly inputRequestId: string;
  readonly bindingId: string;
  readonly expectedBindingVersion: number;
  readonly status: RemoteTaskInputAttemptStatus;
  readonly protocolRevision?: string;
  readonly errorCode?: string;
  readonly startedAt: string;
  readonly completedAt: string;
  readonly durationMs: number;
}

export interface RemoteTaskInputRepository {
  activate(
    input: Readonly<{
      request: TaskInputRequest;
      link: RemoteTaskInputLink;
      claimToken: string;
      processedAt: string;
      phaseMessage: string;
    }>,
  ): Promise<boolean>;
  findLink(inputRequestId: string): Promise<RemoteTaskInputLink | undefined>;
  recordUpdateOutcome(
    input: Readonly<{
      inputRequestId: string;
      expectedBindingVersion: number;
      attempt: RemoteTaskInputAttempt;
      status: Extract<RemoteTaskInputLink['status'], 'update_acknowledged' | 'update_uncertain'>;
      observedAt: string;
    }>,
  ): Promise<Readonly<{ applied: boolean; binding?: RemoteTaskBinding }>>;
  listAttempts(inputRequestId: string): Promise<readonly RemoteTaskInputAttempt[]>;
}

export interface RemoteTaskInputSender {
  updateRemoteTask(
    input: Readonly<{
      serverId: string;
      remoteTaskId: string;
      inputResponses: Readonly<Record<string, unknown>>;
      executionContext: RuntimeExecutionContext;
    }>,
  ): Promise<RemoteTaskOperationAck>;
}

export interface RemoteTaskInputLifecycleEvidence {
  readonly link: RemoteTaskInputLink;
  readonly question: string;
  readonly requestStatus: 'waiting' | 'answered' | 'expired' | 'canceled';
  readonly responseContent?: unknown;
  readonly answeredAt?: string;
  readonly attempts: readonly RemoteTaskInputAttempt[];
}

export interface RemoteTaskCancellationLifecycleEvidence {
  readonly request: RemoteTaskCancellationRequest;
  readonly attempts: readonly RemoteTaskCancellationAttempt[];
}

export interface RemoteTaskContinuationLifecycleEvidence {
  readonly snapshotId: string;
  readonly continuationId: string;
  readonly stateVersion: number;
  readonly lifecycle: 'building' | 'active' | 'superseded' | 'invalidated' | 'terminal';
  readonly waitId: string;
  readonly waitState: 'waiting' | 'awaiting_input';
  readonly nodeId: string;
  readonly nodeRunId: string;
  readonly createdAt: string;
  readonly updatedAt: string;
}

/** Read-only PostgreSQL lifecycle projection for management surfaces. */
export interface RemoteTaskLifecycleEvidence {
  readonly binding: RemoteTaskBinding;
  readonly observations: readonly RemoteTaskObservation[];
  readonly controls: readonly RemoteTaskControlEvent[];
  readonly protocolAttempts: readonly RemoteTaskProtocolAttempt[];
  readonly continuations: readonly RemoteTaskContinuationLifecycleEvidence[];
  readonly inputRounds: readonly RemoteTaskInputLifecycleEvidence[];
  readonly cancellations: readonly RemoteTaskCancellationLifecycleEvidence[];
  readonly frozenProtocol?: Readonly<{
    ttlMs?: number;
    expiresAt?: string;
    runtimeRevision?: string;
    providerRevision?: string;
    latestObservationSource?: 'admission' | 'poll' | 'notification' | 'reconciliation';
    pollHealth: 'healthy' | 'degraded';
    notificationHealth: 'observed' | 'fallback_polling' | 'not_observed';
    evidenceSummary: Readonly<{
      providerItems: number;
      validatedRequirements: number;
      unsatisfiedRequirements: number;
    }>;
  }>;
}

export interface RemoteTaskLifecycleQuery {
  listByAgentTaskId(agentTaskId: string): Promise<readonly RemoteTaskLifecycleEvidence[]>;
}

export interface RemoteTaskCancellationJob {
  readonly requestId: string;
  readonly expectedVersion: number;
}

export interface RemoteTaskCancellationQueue {
  enqueue(input: RemoteTaskCancellationJob): Promise<void>;
  state(requestId: string, expectedVersion: number): Promise<RemoteTaskPollJobState>;
}

export interface WorkflowContinuationRepository {
  saveSnapshot(snapshot: WorkflowContinuationSnapshot): Promise<void>;
  transitionLifecycle(
    snapshotId: string,
    expected: WorkflowContinuationLifecycle,
    next: WorkflowContinuationLifecycle,
    updatedAt: string,
  ): Promise<WorkflowContinuationSnapshot>;
  findById(snapshotId: string): Promise<WorkflowContinuationSnapshot | undefined>;
  findCurrent(workflowInstanceId: string): Promise<WorkflowContinuationSnapshot | undefined>;
  findCurrentByBinding(bindingId: string): Promise<WorkflowContinuationSnapshot | undefined>;
  listInbox(
    now: string,
    limit: number,
    afterEventId?: string,
  ): Promise<readonly RemoteTaskControlEvent[]>;
  claimControl(
    input: Readonly<{
      eventId: string;
      claimToken: string;
      claimedAt: string;
      expiresAt: string;
    }>,
  ): Promise<RemoteTaskControlEvent | undefined>;
  finishControl(
    input: Readonly<{
      eventId: string;
      claimToken: string;
      status: 'processed' | 'failed';
      processedAt: string;
      errorCode?: string;
      bindingDisposition?: 'reentered';
    }>,
  ): Promise<void>;
  saveAttempt(attempt: WorkflowContinuationAttempt): Promise<void>;
  updateAttempt(
    attempt: WorkflowContinuationAttempt,
    expectedStatus: WorkflowContinuationAttemptStatus,
  ): Promise<void>;
  listAttempts(workflowInstanceId: string): Promise<readonly WorkflowContinuationAttempt[]>;
}

export type RemoteTaskPollJobState = 'missing' | 'scheduled' | 'active' | 'completed' | 'failed';

export interface RemoteTaskPollJob {
  readonly bindingId: string;
  readonly expectedVersion: number;
}

export interface RemoteTaskDeadLetter {
  readonly jobId: string;
  readonly bindingId: string;
  readonly expectedVersion: number;
  readonly failedReason: string;
  readonly attemptsMade: number;
}

export interface RemoteTaskPollQueue {
  enqueue(input: RemoteTaskPollJob, runAt: string): Promise<void>;
  state(bindingId: string, expectedVersion: number): Promise<RemoteTaskPollJobState>;
  listDeadLetters(limit: number): Promise<readonly RemoteTaskDeadLetter[]>;
  retryDeadLetter(jobId: string): Promise<void>;
}

export interface RemoteTaskContinuationJob {
  readonly eventId: string;
  readonly bindingId: string;
  readonly eventType: RemoteTaskControlEvent['type'];
}

export interface RemoteTaskContinuationQueue {
  enqueue(input: RemoteTaskContinuationJob): Promise<void>;
  state(eventId: string): Promise<RemoteTaskPollJobState>;
}

export interface ContextSerialGate {
  run<T>(contextId: string, operation: () => Promise<T>): Promise<T>;
}

/** Rebuildable protocol representation; AgentTask remains the system of record. */
export interface ExternalTaskProjection {
  readonly protocol: 'a2a-v1';
  readonly taskId: string;
  readonly contextId: string;
  readonly state: string;
  readonly statusTimestamp?: string;
  readonly document: unknown;
}

export interface ExternalTaskProjectionQuery {
  readonly protocol: ExternalTaskProjection['protocol'];
  readonly contextId?: string;
  readonly state?: string;
  readonly statusTimestampAfter?: string;
  readonly offset: number;
  readonly limit: number;
}

export interface ExternalTaskProjectionRepository {
  find(
    protocol: ExternalTaskProjection['protocol'],
    taskId: string,
  ): Promise<ExternalTaskProjection | undefined>;
  save(projection: ExternalTaskProjection): Promise<void>;
  list(
    query: ExternalTaskProjectionQuery,
  ): Promise<Readonly<{ items: readonly ExternalTaskProjection[]; total: number }>>;
}

export interface PublicSkillCapability {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly tags: readonly string[];
}

export interface EnabledSkillCapabilityProvider {
  listEnabled(): Promise<readonly PublicSkillCapability[]>;
}

export interface JsonSchemaValidationResult {
  readonly valid: boolean;
  readonly errors: readonly string[];
}

export interface JsonSchemaValidator {
  checkSchema(schema: unknown): JsonSchemaValidationResult;
  validate(schema: unknown, value: unknown): JsonSchemaValidationResult;
}

export interface StructuredModelProvider {
  generateStructured(
    input: Readonly<{
      stage: ModelStage;
      instruction: string;
      responseSchema: unknown;
      correctionErrors: readonly string[];
      taskId?: string;
    }>,
  ): Promise<unknown>;
}

export interface WorkflowPlanRepository {
  findPlan(planId: string): Promise<WorkflowPlanRecord | undefined>;
  findConfirmedDefinition(
    workflowDefinitionId: string,
    workflowVersion: number,
  ): Promise<WorkflowPlanRecord | undefined>;
  confirmPlan(
    planId: string,
    correlation: Readonly<{ taskId?: string; confirmedAt: string }>,
  ): Promise<void>;
  saveAttempt(attempt: WorkflowPlanAttempt): Promise<void>;
  savePlan(plan: WorkflowPlanRecord): Promise<void>;
  savePlanAndSupersede(plan: WorkflowPlanRecord, sourcePlanId: string): Promise<void>;
}

export interface WorkflowExecutionRepository {
  findInstance(instanceId: string): Promise<WorkflowInstance | undefined>;
  findActiveByPlanId(planId: string): Promise<WorkflowInstance | undefined>;
  findLatestByPlanId(planId: string): Promise<WorkflowInstance | undefined>;
  listActiveByGoalId(goalId: string): Promise<readonly WorkflowInstance[]>;
  countNodeEvents(instanceId: string): Promise<number>;
  listNodeEvents(instanceId: string): Promise<readonly WorkflowNodeEvent[]>;
  saveInstance(instance: WorkflowInstance): Promise<void>;
  saveNodeEvents(events: readonly WorkflowNodeEvent[]): Promise<void>;
}

export interface SkillCallWorkflowRepository {
  save(record: SkillCallWorkflowRecord): Promise<void>;
  find(
    parentInstanceId: string,
    parentNodeId: string,
  ): Promise<SkillCallWorkflowRecord | undefined>;
  findByChildInstanceId(childInstanceId: string): Promise<SkillCallWorkflowRecord | undefined>;
  listByParent(parentInstanceId: string): Promise<readonly SkillCallWorkflowRecord[]>;
}

export interface WorkflowExecutor {
  execute(
    definition: WorkflowDefinition,
    input: unknown,
    budgetLimits: WorkflowBudgetLimits,
    signal?: AbortSignal,
    executionId?: string,
    executionContext?: RuntimeExecutionContext,
  ): Promise<
    Readonly<{
      status: 'paused' | 'waiting_external' | 'succeeded' | 'failed' | 'canceled';
      result?: unknown;
      errors: Readonly<Record<string, Readonly<{ code: string; message: string }>>>;
      budgetUsage: WorkflowBudgetUsage;
      terminationReason?: WorkflowBudgetTerminationReason;
      events: readonly Readonly<{
        nodeId: string;
        type: 'node_started' | 'node_succeeded' | 'node_failed' | 'node_waiting_external';
        timestamp: string;
        durationMs?: number;
        summary: string;
      }>[];
      pendingConfirmation?: WorkflowInstance['pendingConfirmation'];
      continuation?: WorkflowRuntimeContinuationState;
    }>
  >;
  continueExternal?(
    definition: WorkflowDefinition,
    executionId: string,
    continuation: WorkflowRuntimeContinuationState,
    resolution: WorkflowExternalWaitResolution,
    continuationAttemptId: string,
    signal?: AbortSignal,
  ): ReturnType<WorkflowExecutor['execute']>;
  resumeHumanConfirmation?(
    executionId: string,
    confirmed: WorkflowConfirmationResume,
    signal?: AbortSignal,
  ): ReturnType<WorkflowExecutor['execute']>;
  requestPause?(executionId: string): boolean;
  requestCancel?(executionId: string, interruptCurrent: boolean): boolean;
}

export interface ModelProviderRecord {
  readonly configuration: ModelProviderConfiguration;
  readonly encryptedCredential: string;
}

export type ControlledModelFallbackReason =
  'unavailable' | 'timeout' | 'rate_limited' | 'upstream_error';

export interface ControlledModelRouteResolution {
  readonly routeRef: string;
  readonly candidates: readonly ModelProviderRecord[];
  readonly maxAttempts: number;
  readonly timeoutMs: number;
  readonly fallbackOn: readonly ControlledModelFallbackReason[];
}

export interface ControlledModelRouteResolver {
  resolve(
    input: Readonly<{
      stage: ModelStage;
      operation: 'structured_generation' | 'embedding';
      taskId?: string;
      routeContext?: Readonly<{ taskType?: string; caseType?: string }>;
      boundAt: string;
    }>,
  ): Promise<ControlledModelRouteResolution | undefined>;
}

export interface ModelRuntimeRepository {
  findProvider(providerId: string): Promise<ModelProviderRecord | undefined>;
  findProviderForStage(
    stage: ModelStage,
    operation: ModelInvocationRecord['operation'],
  ): Promise<ModelProviderRecord | undefined>;
  listProviders(): Promise<readonly ModelProviderConfiguration[]>;
  listStageRoutes(): Promise<readonly StageModelRoute[]>;
  saveProvider(record: ModelProviderRecord): Promise<void>;
  saveStageRoute(
    stage: ModelStage,
    operation: ModelInvocationRecord['operation'],
    providerId: string,
    updatedAt: string,
  ): Promise<void>;
  saveInvocation(invocation: ModelInvocationRecord): Promise<void>;
  listInvocations(stage?: ModelStage): Promise<readonly ModelInvocationRecord[]>;
  listInvocationsByTask(taskId: string): Promise<readonly ModelInvocationRecord[]>;
  findActivePromptForStage(stage: ModelStage): Promise<PromptVersion | undefined>;
}

export interface ModelRuntimeBootstrapRepository {
  createProvidersAndRoutesIfEmpty(
    input: Readonly<{
      providers: readonly ModelProviderRecord[];
      routes: readonly Readonly<{
        stage: ModelStage;
        operation: ModelInvocationRecord['operation'];
        providerId: string;
      }>[];
      routedAt: string;
    }>,
  ): Promise<boolean>;
}

export interface PromptRepository {
  findCurrent(stage: ModelStage): Promise<PromptVersion | undefined>;
  findVersion(promptId: string, version: number): Promise<PromptVersion | undefined>;
  listVersions(promptId: string): Promise<readonly PromptVersion[]>;
  saveVersion(version: PromptVersion, setCurrent: boolean): Promise<void>;
  effect(promptId: string, version: number): Promise<PromptEffectSummary>;
}

export interface ModelTransportAdapter {
  generateStructured(
    input: Readonly<{
      configuration: ModelProviderConfiguration;
      credentialHeaders: Readonly<Record<string, string>>;
      instruction: string;
      responseSchema: unknown;
      correctionErrors: readonly string[];
      signal: AbortSignal;
    }>,
  ): Promise<
    Readonly<{
      rawResponse: unknown;
      structuredResult: unknown;
      inputTokens?: number;
      outputTokens?: number;
    }>
  >;
  embed(
    input: Readonly<{
      configuration: ModelProviderConfiguration;
      credentialHeaders: Readonly<Record<string, string>>;
      text: string;
      signal: AbortSignal;
    }>,
  ): Promise<
    Readonly<{
      rawResponse: unknown;
      vector: readonly number[];
      inputTokens?: number;
    }>
  >;
}

export interface ContextTaskQueue {
  enqueue(
    input: Readonly<{
      taskId: string;
      contextId: string;
      attemptId: string;
      mode: 'initial' | 'continue_after_input';
    }>,
  ): Promise<void>;
}

export interface RuntimeEventPublisher {
  publish(event: RuntimeTaskEvent): Promise<void>;
}

export interface RuntimeEventQuery {
  listByTask(taskId: string): Promise<readonly RuntimeTaskEvent[]>;
}

export interface RuntimeTaskEvent {
  readonly eventId: string;
  readonly taskId: string;
  readonly contextId: string;
  readonly eventType: 'task.created' | 'task.phase_changed' | SkillExecutionEvent['eventType'];
  readonly timestamp: string;
  readonly summary: string;
}

export interface Clock {
  now(): string;
  nowMilliseconds?(): number;
}

export interface IdentifierGenerator {
  nextId(
    kind: 'context' | 'task' | 'event' | 'input-request' | 'input-response' | 'attempt',
  ): string;
}
